<?php
session_start();
include_once 'classes/config.php';
include_once 'classes/functions.php';

if (!isset($_SESSION['thank_you'])) {
    header("location:product.php");
}

$orders = $pdo->prepare("SELECT * from tbl_order where odr_id = ?");
$orders->bindParam(1, $_SESSION['thank_you']);
$orders->execute();
$odrs = $orders->fetch();
?>
<!DOCTYPE html>
<html lang="en">
 <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Djenne Beads &AMP; Gem</title>
        <meta name="Description" content="Djenne Beads &AMP; Gem"/>
		<meta name="Keywords" content="Djenne Beads &AMP; Gem"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="fullwidth">
        <!-- Loader -->
        <div id="loader-wrapper">
            <div class="cube-wrapper">
                <div class="cube-folding">
                    <span class="leaf1"></span>
                    <span class="leaf2"></span>
                    <span class="leaf3"></span>
                    <span class="leaf4"></span>
                </div>
            </div>
        </div>
        <!-- /Loader -->
        <div id="wrapper">
            <!-- Page -->
            <div class="page-wrapper">
                <?php include("includes/header.php"); ?>
                <main class="page-main">
                    <div class="block fullheight coming-soon">
                        <div class="container">
                            <div class="title">Thank You For Shopping</div>
                            <p>Your Order Number- <strong><?php echo $odrs['order_number'] ?></strong></p>
                            <p>Your Order Successfully. Please Check Your Email.</p>
                            <p>Go to <a href="./">home page</a> in 5 seconds.</p>
                        </div>
                    </div>
                </main>

            </div>
            <!-- /Page -->
            <!-- /Page Content -->
            <!-- Footer -->
          
           <?php include("includes/footer.php"); ?>
    </body>
</html>
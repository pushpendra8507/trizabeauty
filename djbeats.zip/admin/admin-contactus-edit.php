<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $ctid = sanetize($_REQUEST['eid']);
        $email = addslashes($_POST['email']);
        $phone = addslashes($_POST['phone']);
        $address = addslashes($_POST['address']);
        $facebook = addslashes($_POST['facebook']);
        $twitter = addslashes($_POST['twitter']);
        
        
        $medit = $pdo->prepare("update tbl_contactus set email=?, phone=?, address=?, facebook=?, twitter=? where ctid=?");
        $medit->bindParam(1, $email);
        $medit->bindParam(2, $phone);
        $medit->bindParam(3, $address);
        $medit->bindParam(4, $facebook);
        $medit->bindParam(5, $twitter);
        $medit->bindParam(6, $ctid);
        $medit->execute();
        header('location:admin-contactus.php');
    } else {
        echo '<scrip>alert("You are not permited to access.");window.location="admin-contactus-edit.php"</scrip>';
    }
}
if (isset($_REQUEST['eid'])) {
    $ceid = sanetize($_REQUEST['eid']);
    $meta_name = $pdo->prepare("select * from tbl_contactus where ctid=?");
    $meta_name->bindParam(1, $ceid);
    $meta_name->execute();
    $emname = $meta_name->fetch();
}
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Edit Contact Information
                    <a href="admin-contactus.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a>
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Address</label>
                            <div class="col-sm-10">
                                <input type="text" name="address" value="<?php
                                if (isset($emname['address'])) {
                                    echo stripslashes($emname['address']);
                                }
                                ?>" class="form-control" id="inputEmail3"  required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Phone:</label>
                            <div class="col-sm-10">
                                <input type="text" name="phone" value="<?php
                                if (isset($emname['phone'])) {
                                    echo stripslashes($emname['phone']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                            <div class="col-sm-10">
                                <input type="text" name="email" value="<?php
                                if (isset($emname['email'])) {
                                    echo stripslashes($emname['email']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Facebook</label>
                            <div class="col-sm-10">
                                <input type="text" name="facebook" value="<?php
                                if (isset($emname['facebook'])) {
                                    echo stripslashes($emname['facebook']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Twitter</label>
                            <div class="col-sm-10">
                                <input type="text" name="twitter" value="<?php
                                if (isset($emname['twitter'])) {
                                    echo stripslashes($emname['twitter']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>
    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script src="js/jquery-3.0.0.js" type="text/javascript"></script>
</body>
</html>


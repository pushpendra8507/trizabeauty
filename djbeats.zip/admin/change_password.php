<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $old_pass = sanetize($_POST['old_password']);
        $new_pass = sanetize($_POST['new_password']);

        if (change_password($old_pass, $new_pass) == 1) {
            $msg = "Password Changed Successfully";
        } else {
            $msg = "Incorrect Old Password";
        }
    } else {
        echo '<script>alert("You are not permited to access");window.location="change_password.php"</script>';
    }
}
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Change Password
                    <a href="admin-manage-cms.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                </div>

                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data">
                        <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">Old Password</label>
                                <div class="col-sm-8">
                                    <input type="password" name="old_password" class="form-control" id="inputEmail3" placeholder="Old Password">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-4 col-form-label">New Password</label>
                                <div class="col-sm-8">
                                    <input type="password" name="new_password" class="form-control" id="inputEmail3" placeholder="New Password">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                        <div><?php
                            if (isset($msg) && !empty($msg)) {
                                ?>
                                <td colspan="2" style="text-align: center;color: #953b00;"><div class="field"><?php echo $msg ?></div></td>
                                    <?php
                                }
                                ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
</body>
</html>
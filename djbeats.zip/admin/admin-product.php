<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';
include_once '../classes/PaginateIt.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_REQUEST['did']) && !empty($_REQUEST['did'])) {
    $del_id = sanetize($_REQUEST['did']);
    $pimage = $pdo->prepare("select photourl1, photourl2, photourl3 from tbl_product WHERE pid=?");
    $pimage->bindParam(1, $del_id);
    $pimage->execute();
    $dimage = $pimage->fetch();
    unlink('../' . $dimage['photourl1']);
    unlink('../' . $dimage['photourl2']);
    unlink('../' . $dimage['photourl3']);

    $delete = $pdo->prepare("delete from tbl_product where pid=?");
    $delete->bindParam(1, $del_id);
    $delete->execute();
    header("location:admin-product.php");
}

if (isset($_REQUEST['product'])) {
    if ($_REQUEST['psts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['psts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_product set activatedstatus=? where pid=?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['product']);
    $sqlfeatured->execute();
    echo '<script>window.location="admin-product.php";</script>';
}

if (isset($_REQUEST['featured'])) {
    if ($_REQUEST['fsts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['fsts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_product set featured=? where pid=?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['featured']);
    $sqlfeatured->execute();
    echo '<script>window.location="admin-product.php";</script>';
}

$PaginateIt = new PaginateIt();
$per_page = 10;
$PaginateIt->SetItemsPerPage($per_page);
$PaginateIt->SetLinksToDisplay(10);

$cproduct = $pdo->prepare("SELECT * FROM tbl_product order by pid desc");
$cproduct->execute();
$item_count = $cproduct->rowCount();
$PaginateIt->SetItemCount($item_count);

$product = $pdo->prepare("SELECT * FROM tbl_product order by pid desc" . $PaginateIt->GetSqlLimit());
$product->execute();
$prdt = $product->fetchAll();

$PaginateIt->SetLinksFormat('&laquo; Back', ' ', 'Next &raquo;');

include("includes/top_header.php")
;
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Manage Product 
                    <a href="admin-product-add.php" value="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add Product</a> 
                </div>
                <div class="panel-body">
                    <?php
                    if ($cproduct->rowCount() > 0) {
                        if (isset($_GET['page'])) {
                            $cnt = (($per_page * (int) $_GET['page']) - $per_page) + 1;
                        } else {
                            $cnt = 1;
                        }
                        ?>
                        <div>
                            <table class="table table-dark">
                                <thead>
                                    <tr>
                                        <th scope="col">Sr. No</th>
                                        <th scope="col">Special Offer</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Image</th>
                                        <th scope="col">Add/Edit Size</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Details</th>
                                        <th scope="col">Edit</th>
                                        <th scope="col">Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    
                                    foreach ($prdt as $prdt1) {
                                        $pro_sts = $prdt1['activatedstatus'];
                                        $feat_sts = $prdt1['featured'];
                                        $image = $prdt1['photourl1'];
                                        if ($pro_sts == 0) {
                                            $status_img = '<img src="images/cross.png" width="24" alt="Inactive" title="Inactive">';
                                        } else {
                                            $status_img = '<img src="images/right.png" width="24" alt="Active" title="Active">';
                                        }
                                        if ($feat_sts == 0) {
                                            $fstatus_img = '<img src="images/non-featured.png" width="24" alt="Non-Featured" title="Non-Featured">';
                                        } else {
                                            $fstatus_img = '<img src="images/featured.png" width="24" alt="Featured" title="Featured">';
                                        }
                                        ?>
                                        <tr>
                                            <td><?php echo $cnt ?></td>
                                            <td><a href="#" onclick="ChangeStatusF(<?php echo $prdt1['pid']; ?>,<?php echo $feat_sts; ?>)" class="btm"><?php echo $fstatus_img; ?></a></td>
                                            <td><?php echo $prdt1['name']; ?></td>
                                            <td><?php if (!empty($image)) { ?><img src="../<?php echo $prdt1['photourl1'] ?>" width="50px" height="50px"><?php } else { ?><img src="images/noimage.png" width="50px" height="50px"><?php } ?></td>
                                            <td><a href="admin-product-size.php?size=<?php echo $prdt1['pid'] ?>"><img src="images/add-more.png"></a></td>
                                            <td><a href="#" onclick="ChangeStatus(<?php echo $prdt1['pid']; ?>,<?php echo $pro_sts; ?>)" class="btm"><?php echo $status_img; ?></a></td>
                                            <td><a href="admin-product-details.php?view=<?php echo $prdt1['pid'] ?>"><img src="images/details.png"></a></td>
                                            <td><a href="admin-product-add.php?eid=<?php echo $prdt1['pid'] ?>"><img src="images/edit.png"></a></td>
                                            <td><a href="admin-product.php?did=<?php echo $prdt1['pid'] ?>"><img src="images/delete.png"></a></td>
                                        </tr>
                                        <?php
                                        $cnt = $cnt + 1;
                                    }
                                    ?>
                                </tbody>
                            </table>
                            <?php if ($item_count > $per_page) {
                                ?>
                                <div class="pagination">Pages <?php echo $PaginateIt->GetPageLinks(); ?> </div>
                                <?php
                            }
                        } else {
                            ?><h2 style="text-align: center">Product Not Found !!</h2>
                            <?php
                        }
                        ?>
                    </div>

                </div>
            </div>
            <?php include("includes/footer.php"); ?>
        </div>

        <script>
            $(function () {
                $('.navbar-toggle-sidebar').click(function () {
                    $('.navbar-nav').toggleClass('slide-in');
                    $('.side-body').toggleClass('body-slide-in');
                    $('#search').removeClass('in').addClass('collapse').slideUp(200);
                });

                $('#search-trigger').click(function () {
                    $('.navbar-nav').removeClass('slide-in');
                    $('.side-body').removeClass('body-slide-in');
                    $('.search-input').focus();
                });
            });
        </script>
        <script type="text/javascript">
            function ChangeStatus(pid, activatedstatus)
            {
                document.location.href = "admin-product.php?product=" + pid + "&psts=" + activatedstatus;
            }
        </script>
        <script type="text/javascript">
            function ChangeStatusF(pid, featured)
            {
                document.location.href = "admin-product.php?featured=" + pid + "&fsts=" + featured;
            }
        </script>
</body>
</html>
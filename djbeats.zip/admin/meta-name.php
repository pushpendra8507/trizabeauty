<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
$meta_name = $pdo->prepare("select * from tbl_keywords order by kid ");
$meta_name->execute();
$mname = $meta_name->fetch();
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Meta Type Name
                    <a href="meta-name-edit.php?eid=<?php echo $mname['kid'] ?>" value="Update" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Update</a>
                    <a href="admin-manage-cms.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none; margin-right: 5px;">Back</a>
                </div>
                <div class="panel-body">
                    <table class="table table-dark">
                        <tbody>
                            <tr>
                                <td style="width: 15%;">Title:</td>
                                <td><?php echo html_entity_decode($mname['title']) ?></td>
                            </tr>
                            <tr>
                                <td>Description:</td>
                                <td><?php echo html_entity_decode($mname['description']) ?></td>
                            </tr>
                            <tr>
                                <td>Keywords:</td>
                                <td><?php echo html_entity_decode($mname['keywords']) ?></td>
                            </tr>
                            <tr>
                                <td>Author:</td>
                                <td><?php echo $mname['author'] ?></td>
                            </tr>
                            <tr>
                                <td>Robots:</td>
                                <td><?php echo $mname['robots'] ?></td>
                            </tr>
                            <tr>
                                <td>Rating:</td>
                                <td><?php echo $mname['rating'] ?></td>
                            </tr>
                            <tr>
                                <td>Googlebot:</td>
                                <td><?php echo $mname['googlebot'] ?></td>
                            </tr>
                            <tr>
                                <td>Allow Search:</td>
                                <td><?php echo $mname['allow_search'] ?></td>
                            </tr>
                            <tr>
                                <td>Revisit After:</td>
                                <td><?php echo $mname['revisit_after'] ?></td>
                            </tr>
                            <tr>
                                <td>Language:</td>
                                <td><?php echo $mname['language'] ?></td>
                            </tr>
                            <tr>
                                <td>Distribution:</td>
                                <td><?php echo $mname['distribution'] ?></td>
                            </tr>
                            <tr>
                                <td>Canonical:</td>
                                <td><?php echo $mname['canonical'] ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
</body>
</html>


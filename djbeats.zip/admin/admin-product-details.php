<?php
include_once '../classes/functions.php';
if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
include_once '../classes/config.php';
if (isset($_REQUEST['view'])) {
    $view_id = sanetize($_REQUEST['view']);
    $pview = $pdo->prepare("SELECT tbl_product.*, tbl_category.category_name, tbl_sub_category.sub_category_name from tbl_product LEFT JOIN tbl_category ON tbl_product.cid = tbl_category.cid LEFT JOIN tbl_sub_category ON tbl_product.scid = tbl_sub_category.scid where pid=?");
    $pview->bindParam(1, $view_id);
    $pview->execute();
    $ve = $pview->fetch();
    
    $category_name = sanetize($ve['category_name']);
    $sub_category_name = sanetize($ve['sub_category_name']);
    $name = sanetize($ve['name']);
    $price = sanetize($ve['price']);
    $discount = sanetize($ve['discount']);
    $stock = sanetize($ve['stock']);
    $image1 = sanetize($ve['photourl1']);
    $image2 = sanetize($ve['photourl2']);
    $image3 = sanetize($ve['photourl3']);
    $desc = sanetize($ve['description']);
    $pcolor = $ve['color'];
    $prod_color = explode(',', $pcolor);
    $color_count = count($prod_color);
}


include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Product Detail 
                    <a href="javascript:history.go(-1)" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <?php
                        if (!empty($category_name)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Category Name</label>
                                <div class="col-sm-10">
                                    <?php echo $category_name; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        if (!empty($sub_category_name)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Sub Category Name</label>
                                <div class="col-sm-10">
                                    <?php echo $sub_category_name; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        if (!empty($name)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Product Name</label>
                                <div class="col-sm-10">
                                    <?php echo $name; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        if (!empty($price)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Product Price</label>
                                <div class="col-sm-10">
                                    $<?php echo $price; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }

                        if (!empty($discount)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Discount</label>
                                <div class="col-sm-10">
                                    <?php echo $discount; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        if (!empty($stock)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">In Stock</label>
                                <div class="col-sm-10">
                                    <?php echo $stock; ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        $vpsize = $pdo->prepare("select * from tbl_product_size where pid=?");
                        $vpsize->bindParam(1, $view_id);
                        $vpsize->execute();
                        $vsiz = $vpsize->fetch();
                        $size1 = sanetize($vsiz['size1']);
                        $size2 = sanetize($vsiz['size2']);
                        $size3 = sanetize($vsiz['size3']);
                        $size4 = sanetize($vsiz['size4']);
                        $size5 = sanetize($vsiz['size5']);
                        $size6 = sanetize($vsiz['size6']);
                        $size7 = sanetize($vsiz['size7']);
                        $size8 = sanetize($vsiz['size8']);
                        $size9 = sanetize($vsiz['size9']);
                        $size10 = sanetize($vsiz['size10']);

                        if (!empty($size1) || (!empty($size2)) || (!empty($size3)) || (!empty($size4)) || (!empty($size5)) || (!empty($size6)) || (!empty($size7)) || (!empty($size8)) || (!empty($size9)) || (!empty($size10))) {
                            ?>

                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Product Size</label>
                                <div class="col-sm-5">
                                    <div class="size-list">
                                        <ul  class="size-list-ul">
                                            <?php
                                            if (!empty($size1)) {
                                                ?>
                                                <li><span class="value"><?php echo $size1; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size2)) {
                                                ?>
                                                <li><span class="value"><?php echo $size2; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size3)) {
                                                ?>
                                                <li><span class="value"><?php echo $size3; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size4)) {
                                                ?>
                                                <li><span class="value"><?php echo $size4; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size5)) {
                                                ?>
                                                <li><span class="value"><?php echo $size5; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size6)) {
                                                ?>
                                                <li><span class="value"><?php echo $size6; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size7)) {
                                                ?>
                                                <li><span class="value"><?php echo $size7; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size8)) {
                                                ?>
                                                <li><span class="value"><?php echo $size8; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size9)) {
                                                ?>
                                                <li><span class="value"><?php echo $size9; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }

                                            if (!empty($size10)) {
                                                ?>
                                                <li><span class="value"><?php echo $size10; ?></span></li>
                                                <?php
                                            } else {
                                                
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <?php
                        }
                        if (!empty($color_count > 0)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label"> Color</label>
                                <div class="col-sm-10">
                                    <select class="form-control">
                                        <?php
                                        $sel_color = "";
                                        for ($s = 0; $s <= $color_count; $s++) {
                                            $selected_color = $prod_color[$s];
                                            $color = $pdo->prepare("select * from tbl_color where status = 1 and id=? ORDER BY title ASC");
                                            $color->bindParam(1, $prod_color[$s]);
                                            $color->execute();
                                            $allcolor = $color->fetchAll();
                                            foreach ($allcolor as $clr) {
                                                ?>
                                                <option><?php echo $clr['title'] ?></option>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }
                        if (!empty($desc)) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label"> Description</label>
                                <div class="col-sm-10">
                                    <?php echo html_entity_decode($ve['description']) ?>
                                </div>
                            </div>
                            <?php
                        } else {
                            
                        }

                        if (!empty($image1) || (!empty($image2)) || (!empty($image3))) {
                            ?>
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label"> Product Image</label>
                                <div class="col-sm-10">
                                    <?php if (!empty($image1)) { ?> 
                                        <img src="../<?php echo $image1 ?>" width="110px" height="110px"/>
                                        <?php
                                    } else {
                                        
                                    }
                                    if (!empty($image2)) {
                                        ?>
                                        <img src="../<?php echo $image2 ?>" width="110px" height="110px"/>
                                        <?php
                                    } else {
                                        
                                    }
                                    if (!empty($image3)) {
                                        ?>
                                        <img src="../<?php echo $image3 ?>" width="110px" height="110px"/>
                                        <?php
                                    } else {
                                        
                                    }
                                } else {
                                    
                                }
                                ?>
                                </form>
                            </div>
                        </div>
                </div>
                <?php include("includes/footer.php"); ?>
            </div>

            <script>
                $(function () {
                    $('.navbar-toggle-sidebar').click(function () {
                        $('.navbar-nav').toggleClass('slide-in');
                        $('.side-body').toggleClass('body-slide-in');
                        $('#search').removeClass('in').addClass('collapse').slideUp(200);
                    });

                    $('#search-trigger').click(function () {
                        $('.navbar-nav').removeClass('slide-in');
                        $('.side-body').removeClass('body-slide-in');
                        $('.search-input').focus();
                    });
                });
            </script>

            </body>
            </html>
<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';
include_once '../classes/PaginateIt.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if(isset($_GET['page'])){
    $page =  $_GET['page'];
}else{
    $page = 1;
}
//echo $page;exit;
if (isset($_REQUEST['did']) && !empty($_REQUEST['did'])) {
    $del_id = sanetize($_REQUEST['did']);
    $delete = $pdo->prepare("delete from tbl_color where id=?");
    $delete->bindParam(1, $del_id);
    $delete->execute();
    header("location:admin-color.php");
}

if (isset($_REQUEST['color'])) {
    if ($_REQUEST['csts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['csts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_color set status=? where id=?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['color']);
    $sqlfeatured->execute();
    echo '<script>window.location="admin-color.php?page='.$_REQUEST['page'].'";</script>';
}

$PaginateIt = new PaginateIt();
$per_page = 10;
$PaginateIt->SetItemsPerPage($per_page);
$PaginateIt->SetLinksToDisplay(10);

$ccategory = $pdo->prepare("select * from tbl_color order by id");
$ccategory->execute();
$item_count = $ccategory->rowCount();

$PaginateIt->SetItemCount($item_count);

$category = $pdo->prepare("select * from tbl_color order by id" . $PaginateIt->GetSqlLimit());
$category->execute();
$cat = $category->fetchAll();

$PaginateIt->SetLinksFormat('&laquo; Back', ' ', 'Next &raquo;');

include("includes/top_header.php")
;
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                     Color 
                    <a href="admin-color-add.php" value="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add Color</a> 
                </div>
                <?php
                if ($ccategory->rowCount() > 0) {
                    if (isset($_GET['page'])) {
                        $cnt = (($per_page * (int) $_GET['page']) - $per_page) + 1;
                    } else {
                        $cnt = 1;
                    }
                    ?>
                    <div class="panel-body">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="col">Sr. No</th>
                                    <th scope="col">Color</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($cat as $cate) {
                                    $pro_sts = $cate['status'];
                                    if ($pro_sts == 0) {
                                        $status_img = '<img src="images/cross.png" width="24" alt="Inactive" title="Inactive">';
                                    } else {
                                        $status_img = '<img src="images/right.png" width="24" alt="Active" title="Active">';
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt ?></td>
                                        <td><?php echo $cate['title']; ?></td>
                                        <td><a href="#" onclick="ChangeStatus(<?php echo $cate['id']; ?>,<?php echo $page; ?>,<?php echo $pro_sts; ?>)" class="btm"><?php echo $status_img; ?></a></td>
                                        <td><a href="admin-color-add.php?eid=<?php echo $cate['id'] ?>"><img src="images/edit.png"></a></td>
                                        <td><a href="admin-color.php?did=<?php echo $cate['id'] ?>"><img src="images/delete.png"></a></td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <?php
                    if ($item_count > $per_page) {
                        ?>
                        <div class="pagination" style="float: right">Pages <?php echo $PaginateIt->GetPageLinks(); ?> </div>
                        <?php
                    }
                } else {
                    ?>
                    <center> <h4>Color Not Found !!</h4> </center>
                <?php } ?>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script type="text/javascript">
        function ChangeStatus(id, page, status)
        {
            document.location.href = "admin-color.php?color=" + id + "&page=" + page + "&csts=" + status;
        }
    </script>

</body>
</html>


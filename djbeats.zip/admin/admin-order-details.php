<?php
include_once '../classes/functions.php';
include_once '../classes/config.php';
if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
include_once '../classes/config.php';
if (isset($_REQUEST['vid'])) {
    $ordr = $pdo->prepare("select * from tbl_order where odr_id=?");
    $ordr->bindParam(1, $_REQUEST['vid']);
    $ordr->execute();
    $odd = $ordr->fetch();

    $ordd = $pdo->prepare("select tbl_order_details.*, tbl_order_details.price as order_price, tbl_product.name from tbl_order_details left join tbl_product on tbl_order_details.pid=tbl_product.pid where tbl_order_details.odr_id=?");
    $ordd->bindParam(1, $_REQUEST['vid']);
    $ordd->execute();
    $oddr = $ordd->fetchAll();
}
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <form method="post">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        Order Detail
                        <a href="javascript:history.go(-1)" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                    </div>
                    <div class="panel-body">
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="col">Sr. No</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Size</th>
                                    <th scope="col">Color</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Quantity</th>
                                    <th scope="col">Sub Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $cnt = 1;
                                $totalprice = 0;
                                foreach ($oddr as $odp) {
                                    $subtotal = $odp['quantity'] * $odp['order_price'];
                                    $totalprice += $subtotal
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt ?></td>
                                        <td><?php echo $odp['name'] ?></td>
                                        <td><?php echo $odp['size'] ?></td>
                                        <td><?php echo $odp['color'] ?></td>
                                        <td>$<?php echo $odp['order_price'] ?></td>
                                        <td><?php echo $odp['quantity'] ?></td>
                                        <td>$<?php echo $subtotal; ?></td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                            <tr>
                                <th colspan="4">Grand Total</th>
                                <td>$<?php echo $totalprice; ?></td>
                            </tr>
                        </table>
                    </div>
                </div>
            </form>
            <div class="panel panel-default">
                <div class="panel-heading">
                    Customer Detail
                </div>
                <div class="panel-body">
                    <table class="table table-dark" style="width: 50%; float: left; border: solid 1px;">
                        <tbody>
                            <tr>
                                <th colspan="2">Shipping Address</th>
                            </tr>
                            <tr>
                                <td>Name</td>
                                <td><?php echo $odd['ship_name'] ?></td>
                            </tr>
                            <tr>
                                <td> Email</td>
                                <td><?php echo $odd['ship_email'] ?></td>
                            </tr>
                            <tr>
                                <td> Phone</td>
                                <td><?php echo $odd['ship_phone'] ?></td>
                            </tr>
                            <tr>
                                <td> Address </td>
                                <td><?php echo $odd['ship_street'] . ', ' . $odd['ship_city'] . ', ' . $odd['ship_state'] . ', ' . $odd['ship_country'] . '- ' . $odd['ship_zipcode'] ?></td>
                            </tr>
                        </tbody>
                    </table>

                    <table class="table table-dark" style="width: 50%; float: left; border: solid 1px;">
                        <tbody>
                            <tr>
                                <th colspan="2">Payment Information</th>
                            </tr>
                            <tr>
                                <td>Order No.</td>
                                <td><?php echo $odd['order_number'] ?></td>
                            </tr>
                            <tr>
                                <td>Transaction Id</td>
                                <td><?php echo $odd['paymentid'] ?></td>
                            </tr>
                            <tr>
                                <td>Total Amount</td>
                                <td><?php echo $odd['total_amount'] ?></td>
                            </tr>
                            <tr>
                                <td>Date</td>
                                <td><?php echo date('m/d/Y H:i:s', strtotime($odd['order_date'])) ?></td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>

        </div>
    </div>
</div>
</div>
<?php include("includes/footer.php"); ?>
</div>

<script>
    $(function () {
        $('.navbar-toggle-sidebar').click(function () {
            $('.navbar-nav').toggleClass('slide-in');
            $('.side-body').toggleClass('body-slide-in');
            $('#search').removeClass('in').addClass('collapse').slideUp(200);
        });

        $('#search-trigger').click(function () {
            $('.navbar-nav').removeClass('slide-in');
            $('.side-body').removeClass('body-slide-in');
            $('.search-input').focus();
        });
    });
</script>
</body>
</html>
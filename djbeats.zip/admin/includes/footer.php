<footer class="footer">
    © 2020 Djenne Beads & Gem. All Rights Reserved.<br>
    <a target="_blank" href="http://wxperts.co/"><img src="../images/wxperts_powerdby.jpg" alt="wxperts"></a>
</footer>

<script src="cleditor/jquery.cleditor.min.js"></script>
<script src="cleditor/jquery.cleditor.table.min.js"></script>
<script src="js/mycustom.js"> </script>
<script type="text/javascript">
	$(document).ready(function () { $(".description").cleditor(); });
</script>
<div class="col-md-2 sidebar">
    <div class="row">
        <div class="absolute-wrapper"> </div>
        <div class="side-menu">
            <nav class="navbar navbar-default" role="navigation">
                <div class="side-menu-container">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="dashboard.php"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
                        <li class="panel panel-default" id="dropdown">
                            <a data-toggle="collapse" href="#dropdown-lvl1">
                                <span class="glyphicon glyphicon-user"></span>  Manage Cms <span class="caret"></span>
                            </a>
                            <div id="dropdown-lvl1" class="">
                                <div class="panel-body">
                                    <ul class="nav navbar-nav">
                                        <li><a href="admin-about.php">Manage About</a></li>
                                        <li><a href="admin-category.php">Manage Category</a></li>
                                        <li><a href="admin-sub-category.php">Manage Sub Category</a></li>
                                        <li><a href="admin-color.php">Manage Color</a></li>
                                        <li><a href="admin-product.php">Manage Product</a></li>
                                        <li class=""><a href="admin-clients.php">Manage User</a></li>
                                        <li class=""><a href="admin-order.php">Manage Order</a></li>
                                        <li><a href="admin-manage-cms.php">Manage CMS</a></li>
                                    </ul>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>  
</div>
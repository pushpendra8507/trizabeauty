<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';
include_once '../classes/PaginateIt.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}

if (isset($_REQUEST['about'])) {
    if ($_REQUEST['csts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['csts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_about set activatedstatus=? where abid=?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['about']);
    $sqlfeatured->execute();
    echo '<script>window.location="admin-about.php";</script>';
}

$category = $pdo->prepare("select * from tbl_about");
$category->execute();
$cat = $category->fetchAll();

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Manage About 
                </div>
                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Description</th>
                                <th scope="col">Status</th>
                                <th scope="col">Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($cat as $cate) {
                                $pro_sts = $cate['activatedstatus'];
                                if ($pro_sts == 0) {
                                    $status_img = '<img src="images/cross.png" width="24" alt="Inactive" title="Inactive">';
                                } else {
                                    $status_img = '<img src="images/right.png" width="24" alt="Active" title="Active">';
                                }
                                ?>
                                <tr>
                                    <td><?php echo html_entity_decode($cate['description']); ?></td>
                                    <td><a href="#" onclick="ChangeStatus(<?php echo $cate['abid']; ?>,<?php echo $pro_sts; ?>)" class="btm"><?php echo $status_img; ?></a></td>
                                    <td><a href="admin-about-edit.php?eid=<?php echo $cate['abid'] ?>"><img src="images/edit.png"></a></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script type="text/javascript">
        function ChangeStatus(abid, activatedstatus)
        {
            document.location.href = "admin-about.php?about=" + abid + "&csts=" + activatedstatus;
        }
    </script>

</body>
</html>
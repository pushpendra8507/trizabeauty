<?php

include_once '../../classes/config.php';
if (isset($_REQUEST['cat_id']) && !empty($_REQUEST['cat_id'])) {
    $rf = $pdo->prepare("select * from tbl_sub_category where cid=?");
    $rf->bindParam(1, $_REQUEST['cat_id']);
    $rf->execute();
    $srf = $rf->fetchAll();

    if ($rf->rowCount() > 0) {
        foreach ($srf as $subcat) {
            echo '<option value="' . $subcat["scid"] . '">' . stripslashes($subcat["sub_category_name"]). '</option>';
        }
    } else {
        echo '<option value="">No Sub Category In Selected Category</option>';
    }
}
?>
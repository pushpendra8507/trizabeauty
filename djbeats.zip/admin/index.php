<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (isset($_REQUEST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $LoginId = $_POST["txt_user"];
        $Password = $_POST["txt_password"];

        $LoginId = str_replace("'", "", $LoginId);
        $LoginId = str_replace('"', "", $LoginId);

        $Password = str_replace("'", "", $Password);
        $Password = str_replace('"', "", $Password);


        if (ValidateLogin($LoginId, $Password) == 0) {
            $msg = "Incorrect Login Id Or Password";
        } else {
            header("Location:dashboard.php");
        }
    } else {
        echo '<script>alert("You are not permited to access");</script>';
    }
}
include("includes/top_header.php");
?>

<body>
    <div class="keycode-admin-page">
        <form role="form" method="post">
            <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
            <div id="login">
                <div class="logo-top">
                    <img src="../images/logo.png" class="img-responsive" alt="Dynamic Duo Denim">
                </div>
                <div class="admin-detail">
                    <ul>
                        <li>
                            <label>User Name</label>
                            <input type="text" name="txt_user" id="email" class="form-control" placeholder="User Name">
                        </li>
                        <li>
                            <label>Password</label>
                            <input type="password" name="txt_password" id="password" class="form-control" placeholder="Password">
                        </li>
                        <?php if (isset($msg)) { ?> 
                            <div class="col-md-12 submit">
                                <p> <?php echo $msg ?></p>
                            </div>
                        <?php } ?>
            <!--<input  class="btn_grey" onmouseout="this.className='btn_grey'" onmouseover="this.className='btn_grey_hov'" type="button" id="btnlogin" value="Login"  onclick="CheckLoginThenGo(this.form);" />-->
                        <input type="submit" name="btn_submit" class="btn btn-lg btn-success btn-block" value="SUBMIT">
                        <span><a href="forgot-password.php" onclick="#"> <i class="fa fa-key"></i> Forgot Password?</a></span>
                        <!--<div id="divResponse" class="message"></div>-->
                    </ul>
                </div>
                <div class="clear"></div>

            </div>
        </form>
        <div class="clear"></div>
    </div>
</body>
</html>
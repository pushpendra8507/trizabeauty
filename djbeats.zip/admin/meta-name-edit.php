<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $ctid = sanetize($_REQUEST['eid']);
        $title = addslashes($_POST['title']);
        $description = addslashes($_POST['description']);
        $keywords = addslashes($_POST['keywords']);
        $author = addslashes($_POST['author']);
        $robots = addslashes($_POST['robots']);
        $rating = addslashes($_POST['rating']);
        $googlebot = addslashes($_POST['googlebot']);
        $allow_search = addslashes($_POST['allow_search']);
        $revisit_after = addslashes($_POST['revisit_after']);
        $language = addslashes($_POST['language']);
        $distribution = addslashes($_POST['distribution']);
        $canonical = addslashes($_POST['canonical']);

        $medit = $pdo->prepare("update tbl_keywords set title=?, description=?,keywords =?, author =?,"
                . " robots=?, rating=?, googlebot =?, allow_search =?, revisit_after=?,"
                . " language=?, distribution =?, canonical =? where kid=?");
        $medit->bindParam(1, $title);$medit->bindParam(2, $description);$medit->bindParam(3, $keywords);
        $medit->bindParam(4, $author);$medit->bindParam(5, $robots);$medit->bindParam(6, $rating);
        $medit->bindParam(7, $googlebot);$medit->bindParam(8, $allow_search);$medit->bindParam(9, $revisit_after);
        $medit->bindParam(10, $language);$medit->bindParam(11, $distribution);$medit->bindParam(12, $canonical);
        $medit->bindParam(13, $ctid);
        $medit->execute();
        header('location:meta-name.php');
    } else {
        echo '<scrip>alert("You are not permited to access.");</scrip>';
    }
}
if (isset($_REQUEST['eid'])) {
    $ceid = sanetize($_REQUEST['eid']);
    $meta_name = $pdo->prepare("select * from tbl_keywords where kid=?");
    $meta_name->bindParam(1, $ceid);
    $meta_name->execute();
    $emname = $meta_name->fetch();
}
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Update Meta Type Name
                    <a href="meta-name.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a>
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Title</label>
                            <div class="col-sm-10">
                                <input type="text" name="title" value="<?php
                                if (isset($emname['title'])) {
                                    echo stripslashes($emname['title']);
                                }
                                ?>" class="form-control" id="inputEmail3"  required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Description</label>
                            <div class="col-sm-10">
                                <?php
                                include_once("fckeditor/fckeditor.php");

                                $ctrl_name = 'description';
                                $sBasePath = 'fckeditor/';
                                $oFCKeditor = new FCKeditor($ctrl_name);
                                $oFCKeditor->ToolbarSet = 'Customset';
                                $oFCKeditor->Height = "250px";
                                $oFCKeditor->Width = "100%";
                                $oFCKeditor->BasePath = $sBasePath;
                                $oFCKeditor->Value = html_entity_decode($emname['description']);
                                $oFCKeditor->Create();
                                ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Keywords</label>
                            <div class="col-sm-10">
                                <?php
                                include_once("fckeditor/fckeditor.php");

                                $ctrl_name = 'keywords';
                                $sBasePath = 'fckeditor/';
                                $oFCKeditor = new FCKeditor($ctrl_name);
                                $oFCKeditor->ToolbarSet = 'Customset';
                                $oFCKeditor->Height = "250px";
                                $oFCKeditor->Width = "100%";
                                $oFCKeditor->BasePath = $sBasePath;
                                $oFCKeditor->Value = html_entity_decode($emname['keywords']);
                                $oFCKeditor->Create();
                                ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Author</label>
                            <div class="col-sm-10">
                                <input type="text" name="author" value="<?php
                                if (isset($emname['author'])) {
                                    echo stripslashes($emname['author']);
                                }
                                ?>" class="form-control" id="inputEmail3"  required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Robots:</label>
                            <div class="col-sm-10">
                                <input type="text" name="robots" value="<?php
                                if (isset($emname['robots'])) {
                                    echo stripslashes($emname['robots']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Rating</label>
                            <div class="col-sm-10">
                                <input type="text" name="rating" value="<?php
                                if (isset($emname['rating'])) {
                                    echo stripslashes($emname['rating']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Googlebot</label>
                            <div class="col-sm-10">
                                <input type="text" name="googlebot" value="<?php
                                if (isset($emname['googlebot'])) {
                                    echo stripslashes($emname['googlebot']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Allow Search</label>
                            <div class="col-sm-10">
                                <input type="text" name="allow_search" value="<?php
                                if (isset($emname['allow_search'])) {
                                    echo stripslashes($emname['allow_search']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Revisit After</label>
                            <div class="col-sm-10">
                                <input type="text" name="revisit_after" value="<?php
                                if (isset($emname['revisit_after'])) {
                                    echo stripslashes($emname['revisit_after']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Language</label>
                            <div class="col-sm-10">
                                <input type="text" name="language" value="<?php
                                if (isset($emname['language'])) {
                                    echo stripslashes($emname['language']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Distribution</label>
                            <div class="col-sm-10">
                                <input type="text" name="distribution" value="<?php
                                if (isset($emname['distribution'])) {
                                    echo stripslashes($emname['distribution']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Canonical</label>
                            <div class="col-sm-10">
                                <input type="text" name="canonical" value="<?php
                                if (isset($emname['canonical'])) {
                                    echo stripslashes($emname['canonical']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>
    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script src="js/jquery-3.0.0.js" type="text/javascript"></script>
</body>
</html>


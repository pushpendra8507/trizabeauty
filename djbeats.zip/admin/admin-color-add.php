<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $color_name = sanetize(addslashes($_POST['txt_color']));
        if (empty($_POST['status'])) {
            $stmt = $pdo->prepare("INSERT INTO `tbl_color`(title, status) value(?,1)");
            $stmt->bindParam(1, $color_name);
            $stmt->execute();
            header('location:admin-color-add.php');
        } else {
            $status = sanetize($_POST['status']);
            $stmt = $pdo->prepare("update tbl_color set title=? where id=?");
            $stmt->bindParam(1, $color_name);
            $stmt->bindParam(2, $status);
            $stmt->execute();
            echo '<script>window.location="admin-color.php"</script>';
        }
        
    } else {
        echo 'You are not permited to access';
    }
}
if (isset($_REQUEST['eid'])) {
    $e_id = sanetize($_REQUEST['eid']);
    $cte = $pdo->prepare("select * from tbl_color where id=" . $e_id);
    $cte->bindParam(1, $e_id);
    $cte->execute();
    $ca = $cte->fetch();
}
include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Color 
                    <a href="admin-color.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
                        <input type="hidden" name="status" value="<?php
                        if (isset($_REQUEST['eid'])) {
                            echo $_REQUEST['eid'];
                            } else {
                                echo "";
                            }
                            ?>">
                            <div class="form-group row">
                                <label for="inputEmail3" class="col-sm-2 col-form-label">Color Name</label>
                                <div class="col-sm-10">
                                    <input type="text" name="txt_color" value="<?php
                                    if (isset($ca['title'])) {
                                        echo stripslashes($ca['title']);
                                    }
                                    ?>" class="form-control" id="inputEmail3"  required="">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-10">
                                    <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php include("includes/footer.php"); ?>
        </div>

        <script>
            $(function () {
                $('.navbar-toggle-sidebar').click(function () {
                    $('.navbar-nav').toggleClass('slide-in');
                    $('.side-body').toggleClass('body-slide-in');
                    $('#search').removeClass('in').addClass('collapse').slideUp(200);
                });

                $('#search-trigger').click(function () {
                    $('.navbar-nav').removeClass('slide-in');
                    $('.side-body').removeClass('body-slide-in');
                    $('.search-input').focus();
                });
            });
        </script>
    </body>
    </html>
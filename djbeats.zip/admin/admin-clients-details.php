<?php
include_once '../classes/functions.php';
include_once '../classes/config.php';
if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_REQUEST['view'])) {
    $view = sanetize($_REQUEST['view']);
    $user = $pdo->prepare("select * from tbl_user where uid=?");
    $user->bindParam(1, $view);
    $user->execute();
    $usr = $user->fetch();
}
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Customer Detail
                    <a href="javascript:history.go(-1)" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Back</a> 
                </div>
                <div class="panel-body">
                    <table class="table table-dark">
                        <tbody>
                            <tr>
                                <td> Name</td>
                                <td><?php echo $usr['name'] ?></td>
                            </tr>
                            <tr>
                                <td> Email</td>
                                <td><?php echo $usr['email'] ?></td>
                            </tr>
                            <tr>
                                <td> Phone</td>
                                <td><?php echo $usr['phone'] ?></td>
                            </tr>
                            <tr>
                                <td> Address </td>
                                <td><?php echo $usr['address'] . ", " . $usr['city'] ?><br>
                                    <?php echo $usr['state'] . ", " . $usr['country'] . " - " . $usr['zipcode'] ?> <br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
</div>
<?php include("includes/footer.php"); ?>
</div>

<script>
    $(function () {
        $('.navbar-toggle-sidebar').click(function () {
            $('.navbar-nav').toggleClass('slide-in');
            $('.side-body').toggleClass('body-slide-in');
            $('#search').removeClass('in').addClass('collapse').slideUp(200);
        });

        $('#search-trigger').click(function () {
            $('.navbar-nav').removeClass('slide-in');
            $('.side-body').removeClass('body-slide-in');
            $('.search-input').focus();
        });
    });
</script>
</body>
</html>



<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $psid = sanetize($_POST['prodt_id']);
        $size1 = sanetize(addslashes($_POST['txt_size1']));
        $size2 = sanetize(addslashes($_POST['txt_size2']));
        $size3 = sanetize(addslashes($_POST['txt_size3']));
        $size4 = sanetize(addslashes($_POST['txt_size4']));
        $size5 = sanetize(addslashes($_POST['txt_size5']));
        $size6 = sanetize(addslashes($_POST['txt_size6']));
        $size7 = sanetize(addslashes($_POST['txt_size7']));
        $size8 = sanetize(addslashes($_POST['txt_size8']));
        $size9 = sanetize(addslashes($_POST['txt_size9']));
        $size10 = sanetize(addslashes($_POST['txt_size10']));

        $pcount = $pdo->prepare("select * from tbl_product_size where pid =?");
        $pcount->bindParam(1, $psid);
        $pcount->execute();
        if ($pcount->rowCount() == 0) {
            $psize = $pdo->prepare("Insert into tbl_product_size (pid, size1, size2, size3, size4, size5, size6, "
                            . " size7, size8, size9, size10, activatedstatus) value(?,?,?,?,?,?,?,?,?,?,?,1)");
            $psize->bindParam(1, $psid);
            $psize->bindParam(2, $size1);
            $psize->bindParam(3, $size2);
            $psize->bindParam(4, $size3);
            $psize->bindParam(5, $size4);
            $psize->bindParam(6, $size5);
            $psize->bindParam(7, $size6);
            $psize->bindParam(8, $size7);
            $psize->bindParam(9, $size8);
            $psize->bindParam(10, $size9);
            $psize->bindParam(11, $size10);
            $psize->execute();
            header('location:admin-product.php');
        } else {
            $psize = $pdo->prepare("UPDATE tbl_product_size SET size1=?, size2=?, size3=?, size4=?, size5=?, size6=?, size7=?, size8=?, size9=?, size10=? where pid=?");
            $psize->bindParam(1, $size1);
            $psize->bindParam(2, $size2);
            $psize->bindParam(3, $size3);
            $psize->bindParam(4, $size4);
            $psize->bindParam(5, $size5);
            $psize->bindParam(6, $size6);
            $psize->bindParam(7, $size7);
            $psize->bindParam(8, $size8);
            $psize->bindParam(9, $size9);
            $psize->bindParam(10, $size10);
            $psize->bindParam(11, $psid);
            $psize->execute();
            header('location:admin-product.php');
        }
    } else {
        echo '<script>alert("You are not permited to access");</script>';
    }
}
if (isset($_REQUEST['size'])) {
    $prsid = sanetize($_REQUEST['size']);
    $prosid = $pdo->prepare("select * from tbl_product_size where pid=?");
    $prosid->bindParam(1, $prsid);
    $prosid->execute();
    $spid = $prosid->fetch();
}

include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Add / Edit Product Size
                    <a href="javascript:history.go(-1)" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                </div>
                <div class="panel-body">
                    <form method="post" name="frm" id="frm" enctype="multipart/form-data" action="">
                        <input type="hidden" name="token" value="<?php echo csrf_token(); ?>"/>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" name="txt_size1" value="<?php
                                if (isset($spid['size1'])) {
                                    echo stripslashes($spid['size1']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 1">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" name="txt_size2" value="<?php
                                if (isset($spid['size2'])) {
                                    echo stripslashes($spid['size2']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 2">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" name="txt_size3" value="<?php
                                if (isset($spid['size3'])) {
                                    echo stripslashes($spid['size3']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 3">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" name="txt_size4" value="<?php
                                if (isset($spid['size4'])) {
                                    echo stripslashes($spid['size4']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 4">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" name="txt_size5" value="<?php
                                if (isset($spid['size5'])) {
                                    echo stripslashes($spid['size5']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 5">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" name="txt_size6" value="<?php
                                if (isset($spid['size6'])) {
                                    echo stripslashes($spid['size6']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 6">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" name="txt_size7" value="<?php
                                if (isset($spid['size7'])) {
                                    echo stripslashes($spid['size7']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 7">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" name="txt_size8" value="<?php
                                if (isset($spid['size8'])) {
                                    echo stripslashes($spid['size8']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 8">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6">
                                <input type="text" name="txt_size9" value="<?php
                                if (isset($spid['size9'])) {
                                    echo stripslashes($spid['size9']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 9">
                            </div>
                            <div class="col-sm-6">
                                <input type="text" name="txt_size10" value="<?php
                                if (isset($spid['size10'])) {
                                    echo stripslashes($spid['size10']);
                                }
                                ?>" class="form-control" id="inputEmail3" placeholder="Product Size 10">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <input type="hidden" name="prodt_id" value="<?php echo $_REQUEST['size'] ?>">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>

    <script src="js/jquery.min.js" type="text/javascript"></script>
    <script>
        function getSubCategory(val) {
            $.ajax({
                type: "POST",
                url: "ajax_files/get_subcat.php",
                data: 'cat_id=' + val,
                success: function (data) {
                    $("#ddl_subcategory").html(data);
                }
            });
        }
    </script>

    <script src="tinymce/js/tinymce/tinymce.min.js"></script>
    <script> tinymce.init({selector: 'textarea', plugins: [
                'advlist autolink lists link image charmap print preview anchor',
                'searchreplace visualblocks ',
                'insertdatetime media table contextmenu paste'
            ],
            toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image code',
            powerpaste_allow_local_images: true,
            powerpaste_word_import: 'prompt',
            powerpaste_html_import: 'prompt',
            content_css: [
                '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
                '//www.tinymce.com/css/codepen.min.css']});</script>
</body>
</html>
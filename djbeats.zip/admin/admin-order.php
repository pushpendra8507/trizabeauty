<?php
include_once '../classes/functions.php';
include_once '../classes/config.php';
if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}

$orders = $pdo->prepare("SELECT * from tbl_order order by odr_id desc");
$orders->execute();
$odrs = $orders->fetchAll();

if (isset($_REQUEST['odid'])) {
    $delete = $pdo->prepare("Delete tbl_order, tbl_order_details from tbl_order inner join tbl_order_details where tbl_order.odr_id=tbl_order_details.odr_id and tbl_order.odr_id=?");
    $delete->bindParam(1, $_REQUEST['odid']);
    $delete->execute();
    header('location:admin-order.php');
}
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Our Order
                </div>
                <div class="panel-body">
                    <?php if ($orders->rowCount() > 0) { ?>
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="col">Sr. No</th>
                                    <th scope="col">Order Number</th>
                                    <th scope="col"> Name</th>
                                    <th scope="col"> Mobile</th>
                                    <th scope="col"> Email</th>
                                    <th scope="col"> Details</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $cnt = 1;
                                foreach ($odrs as $pr) {
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt ?></td>
                                        <td><?php echo $pr['order_number'] ?></td>
                                        <td><?php echo $pr['ship_name'] ?></td>
                                        <td><?php echo $pr['ship_phone'] ?></td>
                                        <td><?php echo $pr['ship_email'] ?></td>
                                        <td><a href="admin-order-details.php?vid=<?php echo $pr['odr_id'] ?>"><img src="images/details.png" title="Details"></a></td>
                                        <td><a href="admin-order.php?odid=<?php echo $pr['odr_id'] ?>"><img src="images/delete.png" title="Delete"></a></td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                    } else {
                        ?>
                        <h2 style="text-align: center">Order Not Found !!</h2>
                        <?php
                    }
                    ?>
                </div>

            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
</body>
</html>


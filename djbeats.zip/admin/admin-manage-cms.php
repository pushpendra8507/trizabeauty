<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
$meta_name = $pdo->prepare("select * from tbl_contactus order by ctid ");
$meta_name->execute();
$mname = $meta_name->fetch();
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Manage CMS
                </div>
                <div class="panel-body">
                    <table class="table table-dark">
                        <tbody>
                            <tr>
                                <td style="width: 85%"><a href="admin-contactus.php"><i>Contact Information</i></a></td>
                                <td><button><a href="admin-contactus.php"> <i>Click Here</i></a></button></td>
                            </tr>
                            <tr>
                                <td style="width: 85%"><a href="change_password.php"><i>Change Password</i></a></td>
                                <td><button><a href="change_password.php"><i>Click Here</i></a></button></td>
                            </tr>
                            <tr>
                                <td style="width: 85%"><a href="change-email.php"><i>Change Email</i></a></td>
                                <td><button><a href="change-email.php"> <i>Click Here</i></a></button></td>
                            </tr>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
</body>
</html>
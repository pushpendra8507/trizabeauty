<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

$change = $pdo->prepare("select * from tbl_admin where activatedstatus = 1 ");
$change->execute();
$fpass = $change->fetch();
$username = sanetize($fpass['username']);
$password = sanetize($fpass['password']);
$aemail = sanetize($fpass['email']);

$to = $aemail;
//$to = 'ram.sharan@wserve.com'; // add additional mail receipient here
$fromMail = $aemail;
$fromName = 'Emilys Banquet Hall';
$subject = 'Admin Panel Password';
$message = '<html><head><title>Emilys Banquet Hall</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
		<table  width="60%" border="0" align="center" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">
		
	<tr bgcolor="#000" valign="top">
		  <td height="15"  colspan="2" style="font:bold 21px  Arial, Helvetica, sans-serif; color:#ffff"><center><img src="../img/logo.png" class="img-responsive" alt="Emilys Banquet Hall"></center></td>
		</tr>
		</table>
        <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
        <tbody>
           <tr>
            <td width="100%" valign="top">
                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                    <tbody>		
                       <tr bgcolor="#000">
                        <td colspan="2" class="billing_hd" style="color:#FFF"><center><strong>Admin Panel User Name And Password</strong></center></td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd">User Name:</td>
                            <td width="70%" class="ship_dt">' . $username . '</td>
                        </tr>
                        <tr>
                            <td class="ship_hd">Password:</td>
                            <td class="ship_dt">' . $password . '</td>
                        </tr>
                        
                   </table>
		</td>
		</tr></tbody>
  </table>
  </div></body></html>';
// To send HTML mail, the Content-type header must be set
$headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
$headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
$message = str_replace("\'", "'", $message);
//echo $message;exit;
$send_mail = mail($to, $subject, $message, $headers);

if ($send_mail) {
    echo '<script>alert("Password send successfully. Please check your Email.");window.location="index.php"</script>';
} else {
    echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="index.php"</script>';
}
?>
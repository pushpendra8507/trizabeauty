<?php
include_once '../classes/functions.php';
include_once '../classes/config.php';
if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}

if (isset($_REQUEST['did']) && !empty($_REQUEST['did'])) {
    $del_id = sanetize($_REQUEST['did']);
    $delete = $pdo->prepare("delete from tbl_user where uid=?");
    $delete->bindParam(1, $del_id);
    $delete->execute();
    header("location:admin-clients.php");
}

if (isset($_REQUEST['customer'])) {
    if ($_REQUEST['csts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['csts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_user set activatedstatus=? where uid=?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['customer']);
    $sqlfeatured->execute();
    echo '<script>window.location="admin-clients.php";</script>';
}

$userall = $pdo->prepare("select * from tbl_user order by uid desc");
$userall->execute();
$users = $userall->fetchAll();
include("includes/top_header.php");
?>
<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Manage Clients
                </div>
                <div class="panel-body">
                    <?php if ($userall->rowCount() > 0) { ?>
                        <table class="table table-dark">
                            <thead>
                                <tr>
                                    <th scope="col">Sr. No</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Phone</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Details</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $cnt = 1;
                                foreach ($users as $usr) {
                                    $c_sts = $usr['activatedstatus'];
                                    if ($c_sts == 0) {
                                        $status_img = '<img src="images/cross.png" width="24" alt="Inactive" title="Inactive">';
                                    } else {
                                        $status_img = '<img src="images/right.png" width="24" alt="Active" title="Active">';
                                    }
                                    ?>
                                    <tr>
                                        <td><?php echo $cnt ?></td>
                                        <td><?php echo $usr['name'] ?></td>
                                        <td><?php echo $usr['email'] ?></td>
                                        <td><?php echo $usr['phone'] ?></td>
                                        <td><a href="#" onclick="ChangeStatus(<?php echo $usr['uid']; ?>,<?php echo $c_sts; ?>)" class="btm"><?php echo $status_img; ?></a></td>
                                        <td><a href="admin-clients-details.php?view=<?php echo $usr['uid'] ?>"><img src="images/details.png"></a></td>
                                        <td><a href="admin-clients.php?did=<?php echo $usr['uid'] ?>" onclick="return confirm('Are you sure delete.')"><img src="images/delete.png" title="Delete"></a></td>
                                    </tr>
                                    <?php
                                    $cnt++;
                                }
                                ?>
                            </tbody>
                        </table>
                        <?php
                    } else {
                        ?>
                        <h2 style="text-align: center">User Not Found !!</h2>
                        <?php
                    }
                    ?>
                </div>
                
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script type="text/javascript">
        function ChangeStatus(user_id, activatedstatus)
        {
            document.location.href = "admin-clients.php?customer=" + user_id + "&csts=" + activatedstatus;
        }
    </script>

</body>
</html>


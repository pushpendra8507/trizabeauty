<?php
session_start();
unset($_SESSION['admin']);
unset($_SESSION['email']);
header('location:index.php');
?>


<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';

if (!isset($_SESSION["admin"])) {
    header('loscaion:index.php');
}
if (isset($_POST['btn_submit'])) {
    if (verify_token($_POST['token']) == 'yes') {
        $ddl_category = sanetize(addslashes($_POST['ddl_category']));
        $ddl_subcategory = sanetize(addslashes($_POST['ddl_subcategory']));
        $name = sanetize(addslashes($_POST['txt_name']));
        $price = sanetize(addslashes($_POST['txt_price']));
        $discount = addslashes($_POST['discount']);
        $stock = sanetize(addslashes($_POST['stock']));
        $alt_name1 = sanetize(addslashes($_POST['alt_name1']));
        $alt_name2 = sanetize(addslashes($_POST['alt_name2']));
        $alt_name3 = sanetize(addslashes($_POST['alt_name3']));
        $description = sanetize(addslashes($_POST['description']));
        $color = $_POST['color'];
        $mcolor = implode(',', $color);
        $alias = alias_url($name);
        if (empty($_POST['status'])) {
            $stmt = $pdo->prepare("INSERT INTO `tbl_product`(`cid`, `scid`, `name`, `price`, `discount`, `stock`, `alt_name1`, `alt_name2`, `alt_name3`, `description`, `color`, `alias`, `activatedstatus`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1)");
            $stmt->bindParam(1, $ddl_category);
            $stmt->bindParam(2, $ddl_subcategory);
            $stmt->bindParam(3, $name);
            $stmt->bindParam(4, $price);
            $stmt->bindParam(5, $discount);
            $stmt->bindParam(6, $stock);
            $stmt->bindParam(7, $alt_name1);
            $stmt->bindParam(8, $alt_name2);
            $stmt->bindParam(9, $alt_name3);
            $stmt->bindParam(10, $description);
            $stmt->bindParam(11, $mcolor);
            $stmt->bindParam(12, $alias);
            $stmt->execute();

            $last_insert_id = $pdo->lastInsertId();
            $aliass = $alias . '-' . $last_insert_id;

            if (isset($_FILES['fu_photo1']) && $_FILES['fu_photo1']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo1'], $path, alias_url($alt_name1) . '-1-' . $last_insert_id, 'tbl_product', 'photourl1', 'pid', $last_insert_id);
            }
            if (isset($_FILES['fu_photo2']) && $_FILES['fu_photo2']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo2'], $path, alias_url($alt_name2) . '-2-' . $last_insert_id, 'tbl_product', 'photourl2', 'pid', $last_insert_id);
            }
            if (isset($_FILES['fu_photo3']) && $_FILES['fu_photo3']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo3'], $path, alias_url($alt_name3) . '-3-' . $last_insert_id, 'tbl_product', 'photourl3', 'pid', $last_insert_id);
            }

            $astmt = $pdo->prepare("UPDATE `tbl_product` SET `alias`=? WHERE pid=?");
            $astmt->bindParam(1, $aliass);
            $astmt->bindParam(2, $last_insert_id);
            $astmt->execute();
            header('loscaion:admin-product-add.php');
        } else {
            $status = sanetize($_POST['status']);
            $aliass = $alias . '-' . $status;

            $stmt = $pdo->prepare("UPDATE `tbl_product` SET `cid`=?, `scid`=?, `name`=?,`price`=?,`discount`=?,`stock`=?,`alt_name1`=?,`alt_name2`=?,`alt_name3`=?,`description`=?, `color`=?, `alias`=? WHERE pid=?");
            $stmt->bindParam(1, $ddl_category);
            $stmt->bindParam(2, $ddl_subcategory);
            $stmt->bindParam(3, $name);
            $stmt->bindParam(4, $price);
            $stmt->bindParam(5, $discount);
            $stmt->bindParam(6, $stock);
            $stmt->bindParam(7, $alt_name1);
            $stmt->bindParam(8, $alt_name2);
            $stmt->bindParam(9, $alt_name3);
            $stmt->bindParam(10, $description);
            $stmt->bindParam(11, $mcolor);
            $stmt->bindParam(12, $aliass);
            $stmt->bindParam(13, $status);
            $stmt->execute();

            if (isset($_FILES['fu_photo1']) && $_FILES['fu_photo1']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo1'], $path, alias_url($alt_name1) . '-1-' . $status, 'tbl_product', 'photourl1', 'pid', $status);
            }
            if (isset($_FILES['fu_photo2']) && $_FILES['fu_photo2']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo2'], $path, alias_url($alt_name2) . '-2-' . $status, 'tbl_product', 'photourl2', 'pid', $status);
            }
            if (isset($_FILES['fu_photo3']) && $_FILES['fu_photo3']['name'] != "") {
                $path = 'uploads/';
                UploadImage($_FILES['fu_photo3'], $path, alias_url($alt_name3) . '-3-' . $status, 'tbl_product', 'photourl3', 'pid', $status);
            }
            echo '<script>window.location="admin-product.php"</script>';
        }
    } else {
        echo 'You are not permited to access';
    }
}
if (isset($_REQUEST['eid'])) {
    $e_id = sanetize($_REQUEST['eid']);
    $product = $pdo->prepare("select * from tbl_product where pid=?");
    $product->bindParam(1, $e_id);
    $product->execute();
    $prdt = $product->fetch();

    $p_color = $prdt['color'];
    $prod_color = explode(',', $p_color);
    $color_count = count($prod_color);
}

$color = $pdo->prepare("select * from tbl_color where status = 1 ORDER BY title ASC");
$color->execute();
$allcolor = $color->fetchAll();

include("includes/top_header.php");
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php
                    if (isset($_REQUEST['eid'])) {
                        echo "Edit";
                    } else {
                        echo "Add";
                    }
                    ?> Product
                    <a href="admin-product.php" value="Back" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;"> Back</a> 
                </div>
                <div class="panel-body">
                    <form method="post" enctype="multipart/form-data" action="">
                        <input type="hidden" value="<?php echo csrf_token() ?>" name="token">
                        <input type="hidden" name="status" value="<?php
                        if (isset($_REQUEST['eid'])) {
                            echo $_REQUEST['eid'];
                        } else {
                            echo "";
                        }
                        ?>">
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Select Category</label>
                            <div class="col-sm-10">
                                <select name="ddl_category" class="form-control" id="ddl_category" onchange="getSubCategory(this.value)">
                                    <option value="">Select Category</option>
                                    <?php
                                    $cte = $pdo->prepare("select * from tbl_category where activatedstatus=1");
                                    $cte->execute();
                                    $cca = $cte->fetchAll();
                                    foreach ($cca as $sca) {
                                        ?>
                                        <option value="<?php echo $sca['cid']; ?>" <?php
                                        if (isset($prdt['cid']) && $prdt['cid'] == $sca['cid']) {
                                            echo 'selected';
                                        }
                                        ?>><?php echo $sca['category_name']; ?></option>

                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Select Sub Category</label>
                            <div class="col-sm-10">
                                <select name="ddl_subcategory" class="form-control" id="ddl_subcategory" >
                                    <option>Select Sub Category</option>
                                    <?php
                                    $sctea = $pdo->prepare("select * from tbl_sub_category where cid=?");
                                    $sctea->bindParam(1, $prdt['cid']);
                                    $sctea->execute();
                                    $scca = $sctea->fetchAll();
                                    foreach ($scca as $scta) {
                                        ?>
                                        <option value="<?php echo $scta['scid']; ?>" <?php
                                        if (isset($prdt['scid']) && $prdt['scid'] == $scta['scid']) {
                                            echo 'selected';
                                        }
                                        ?>><?php echo $scta['sub_category_name']; ?></option>
                                                <?php
                                            }
                                            ?>
                                </select></div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Product Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="txt_name" value="<?php
                                if (isset($prdt['name'])) {
                                    echo stripslashes($prdt['name']);
                                }
                                ?>" class="form-control" id="inputEmail3"  required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Product Price</label>
                            <div class="col-sm-10">
                                <input type="text" name="txt_price" value="<?php
                                if (isset($prdt['price'])) {
                                    echo stripslashes($prdt['price']);
                                }
                                ?>" class="form-control" id="inputEmail3"   required="">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Discount</label>
                            <div class="col-sm-10">
                                <input type="text" name="discount" value="<?php
                                if (isset($prdt['discount'])) {
                                    echo stripslashes($prdt['discount']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">In Stock</label>
                            <div class="col-sm-10">
                                <input type="text" name="stock" value="<?php
                                if (isset($prdt['stock'])) {
                                    echo stripslashes($prdt['stock']);
                                }
                                ?>" class="form-control" id="inputEmail3" required="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Image 1</label>
                            <div class="col-sm-10">
                                <input type="file" name="fu_photo1" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Alt Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="alt_name1" value="<?php
                                if (isset($prdt['alt_name1'])) {
                                    echo stripslashes($prdt['alt_name1']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Image 2</label>
                            <div class="col-sm-10">
                                <input type="file" name="fu_photo2" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Alt Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="alt_name2" value="<?php
                                if (isset($prdt['alt_name2'])) {
                                    echo stripslashes($prdt['alt_name2']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Image 3</label>
                            <div class="col-sm-10">
                                <input type="file" name="fu_photo3" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Alt Name</label>
                            <div class="col-sm-10">
                                <input type="text" name="alt_name3" value="<?php
                                if (isset($prdt['alt_name3'])) {
                                    echo stripslashes($prdt['alt_name3']);
                                }
                                ?>" class="form-control" id="inputEmail3">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Select Color</label>
                            <div class="col-sm-10">
                                <?php
                                $cnt = 0;
                                foreach ($allcolor as $clr) {
                                    $sel_color = "";
                                    for ($s = 0; $s <= $color_count; $s++) {
                                        $selected_color = $prod_color[$s];
                                        if ($selected_color == $clr['id']) {
                                            $sel_color = 'checked';
                                        }
                                    }
                                    ?>
                                    <input type="checkbox" name="color[]" value="<?php echo stripslashes($clr['id']); ?>" <?php echo $sel_color; ?>>
                                    <label for="color"><?php echo stripslashes($clr['title']); ?></label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <?php
                                    $cnt++;
                                    if ($cnt % 4 == 0) {
                                        
                                        echo '<input type="checkbox" name="color[]" value="' . stripslashes($clr['id']) . '" ' . $sel_color . '>
                                    <label for="color">' . stripslashes($clr['title']) . '</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>';
                                    }
                                }
                                ?>
                            </div>
                        </div>

                        
                        <div class="form-group">
                            <div class="col-md-12">
                                <label for="inputEmail3">Description </label>
                                <textarea class="form-control description" name="description" required><?php echo (isset($prdt['description']))? html_entity_decode($prdt['description']):'' ?></textarea>
                                
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <div class="col-sm-10">
                                <button type="submit" name="btn_submit" value="SUBMIT" class="btn btn-primary">SUBMIT</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script>
        function getSubCategory(val) {
            $.ajax({
                type: "POST",
                url: "ajax_files/get_subcat.php",
                data: 'cat_id=' + val,
                success: function (data) {
                    $("#ddl_subcategory").html(data);
                }
            });
        }

    </script>
</body>
</html>
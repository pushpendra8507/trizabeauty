<?php
include_once '../classes/config.php';
include_once '../classes/admin_functions.php';
include_once '../classes/PaginateIt.php';

if (!isset($_SESSION["admin"])) {
    header('location:index.php');
}
if (isset($_REQUEST['did']) && !empty($_REQUEST['did'])) {
    $del_id = sanetize($_REQUEST['did']);
    $delete = $pdo->prepare("delete from tbl_sub_category where scid=?");
    $delete->bindParam(1, $del_id);
    $delete->execute();
    header("location:admin-sub-category.php");
}

if (isset($_REQUEST['subcategory'])) {
    if ($_REQUEST['scsts'] == 0) {
        $updatedsts = 1;
    } else if ($_REQUEST['scsts'] == 1) {
        $updatedsts = 0;
    }
    $sqlfeatured = $pdo->prepare("update tbl_sub_category set activatedstatus=? where scid= ?");
    $sqlfeatured->bindParam(1, $updatedsts);
    $sqlfeatured->bindParam(2, $_REQUEST['subcategory']);
    $sqlfeatured->execute();
    header("location:admin-sub-category.php");
    
}

$PaginateIt = new PaginateIt();
$per_page = 10;
$PaginateIt->SetItemsPerPage($per_page);
$PaginateIt->SetLinksToDisplay(10);

$ccategory = $pdo->prepare("select tbl_sub_category.*, tbl_category.category_name from tbl_sub_category left join tbl_category on tbl_sub_category.cid = tbl_category.cid order by scid");
$ccategory->execute();
$item_count = $ccategory->rowCount();

$PaginateIt->SetItemCount($item_count);

$cat = $pdo->prepare("select tbl_sub_category.*, tbl_category.category_name from tbl_sub_category left join tbl_category on tbl_sub_category.cid = tbl_category.cid order by scid" . $PaginateIt->GetSqlLimit());
$cat->execute();
$scate = $cat->fetchAll();

$PaginateIt->SetLinksFormat('&laquo; Back', ' ', 'Next &raquo;');

include("includes/top_header.php")
;
?>

<body>
    <?php include("includes/header.php"); ?>
    <div class="container-fluid main-container">
        <?php include("includes/sidebar.php"); ?>	
        <div class="col-md-10 content">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Sub Category
                    <a href="admin-sub-category-add.php" value="Add" class="btn btn-default" style="float: right; padding: 5px; margin-top: -5px; background: #fff; border: none;">Add Sub Category</a> 
                </div>
                <?php
                if ($ccategory->rowCount() > 0) {
                    if (isset($_GET['page'])) {
                        $cnt = (($per_page * (int) $_GET['page']) - $per_page) + 1;
                    } else {
                        $cnt = 1;
                    }
                    ?>
                <div class="panel-body">
                    <table class="table table-dark">
                        <thead>
                            <tr>
                                <th scope="col">Sr. No</th>
                                <th scope="col">Category</th>
                                <th scope="col">Sub Category</th>
                                <th scope="col">Status</th>
                                <th scope="col">Edit</th>
                                <th scope="col">Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach($scate as $cate) {
                                $pro_sts = $cate['activatedstatus'];
                                if ($pro_sts == 0) {
                                    $status_img = '<img src="images/cross.png" width="24" alt="Inactive" title="Inactive">';
                                } else {
                                    $status_img = '<img src="images/right.png" width="24" alt="Active" title="Active">';
                                }
                                
                                ?>
                                <tr>
                                    <td><?php echo $cnt ?></td>
                                    <td><?php echo $cate['category_name'] ?></td>
                                    <td><?php echo $cate['sub_category_name'] ?></td>
                                    <td><a href="#" onclick="ChangeStatus(<?php echo $cate['scid']; ?>,<?php echo $pro_sts; ?>)" class="btm"><?php echo $status_img; ?></a></td>
                                    <td><a href="admin-sub-category-add.php?eid=<?php echo $cate['scid'] ?>"><img src="images/edit.png"></a></td>
                                    <td><a href="admin-sub-category.php?did=<?php echo $cate['scid'] ?>"><img src="images/delete.png"></a></td>
                                </tr>
                                <?php
                                $cnt++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <?php
                    if ($item_count > $per_page) {
                        ?>
                        <div class="pagination" style="float: right">Pages <?php echo $PaginateIt->GetPageLinks(); ?> </div>
                        <?php
                    }
                } else {
                    ?>
                    <center> <h4> Sub Category Not Found !!</h4> </center>
                <?php } ?>
            </div>
        </div>
        <?php include("includes/footer.php"); ?>
    </div>

    <script>
        $(function () {
            $('.navbar-toggle-sidebar').click(function () {
                $('.navbar-nav').toggleClass('slide-in');
                $('.side-body').toggleClass('body-slide-in');
                $('#search').removeClass('in').addClass('collapse').slideUp(200);
            });

            $('#search-trigger').click(function () {
                $('.navbar-nav').removeClass('slide-in');
                $('.side-body').removeClass('body-slide-in');
                $('.search-input').focus();
            });
        });
    </script>
    <script type="text/javascript">
        function ChangeStatus(scid, activatedstatus)
        {
            document.location.href = "admin-sub-category.php?subcategory=" + scid + "&scsts=" + activatedstatus;
        }
    </script>
</body>
</html>


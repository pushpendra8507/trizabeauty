<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';
if (isset($_POST['btn_login'])) {

    $LoginId = $_REQUEST["loginid"];
    $Password = $_REQUEST["password"];

    $LoginId = str_replace("'", "", $LoginId);
    $LoginId = str_replace('"', "", $LoginId);

    $Password = str_replace("'", "", $Password);
    $Password = str_replace('"', "", $Password);

    if (check_login($LoginId, $Password) == '1') {
        if (isset($_SESSION['checkout'])) {
            echo"<script>window.location='cart.php'</script>";
        } else {
            //echo '<script>alert("Login Sucessfully.");</script>';
            echo "<script>window.location='./'</script>";
        }
    } else {
        echo"<script>alert('Invalid Email or Password')</script>";
        echo"<script>window.location='account-create.php'</script>";
    }
    echo"<script>window.location='account-create.php'</script>";
}
if (isset($_POST['btn_logout'])) {
    user_logout();
}

$meta_name = $pdo->prepare("select * from tbl_contactus order by ctid ");
$meta_name->execute();
$mname = $meta_name->fetch();
?>
<header class="page-header variant-1 fullboxed sticky smart">
    <div class="navbar">
        <div class="container">
            <!-- Menu Toggle -->
            <div class="menu-toggle"><a href="#" class="mobilemenu-toggle"><i class="icon icon-menu"></i></a></div>
            <!-- /Menu Toggle -->
            <!-- Header Cart -->
            <div class="header-link dropdown-link header-cart variant-1">
                <a href="cart.php"> <i class="icon icon-cart"></i> <span class="badge"><?php echo cartCounter() ?></span> </a>
                <!-- minicart wrapper -->
                <div class="dropdown-container right">
                    <!-- minicart content -->
                    <div class="block block-minicart">
                        <div class="minicart-content-wrapper">
                            <div class="block-title">
                                <span>Recently added item(s)</span>
                            </div>
                            <a class="btn-minicart-close" title="Close">&#10060;</a>

                        </div>
                    </div>
                    <!-- /minicart content -->
                </div>
                <!-- /minicart wrapper -->
            </div>
            <!-- /Header Cart -->
            <!-- Header Links -->
            <div class="header-links">

                <!-- Header Account -->
                <div class="header-link">
                    <a href="tel:3139656620"><i class="icon icon-phone"></i> <?php echo $mname['phone'] ?></a>
                </div>

                <div class="header-link dropdown-link header-account">
                    <a href="#"><i class="icon icon-user"></i></a>
                    <?php if (!isset($_SESSION['myuid']) && !isset($_SESSION['myemail'])) { ?>
                        <div class="dropdown-container right">
                            <div class="top-text">If you have an account with us, please log in.</div>
                            <!-- form -->
                            <form method="post">
                                <input type="text" name="loginid" required="" class="form-control" placeholder="E-mail*">
                                <input type="password" name="password" required="" class="form-control" placeholder="Password*">
                                <button type="submit" name="btn_login" class="btn">Sign in</button>
                            </form>
                            <!-- /form -->
                            <div class="title">OR</div>
                            <div class="bottom-text">Create a <a href="account-create.php">New Account</a></div>
                        </div>
                    <?php } else if (isset($_SESSION['myuid']) && isset($_SESSION['myemail'])) { ?>
                        <div class="dropdown-container right log">
                            <form method="post" class="form-log">
                                <button type="submit" name="btn_logout" class="btn">Logout</button>
                            </form>
                        </div>
                    <?php } ?>
                </div>


                <!-- /Header Account -->

            </div>
            <!-- /Header Links -->

            <!-- Logo -->
            <div class="header-logo">
                <h3><a href="./" title="Logo">
                        <img src="images/logo.png" alt="womens fashion online">
                    </a></h3>
            </div>
            <!-- /Logo -->
            <!-- Mobile Menu -->
            <div class="mobilemenu dblclick">
                <div class="mobilemenu-header">
                    <div class="title">MENU</div>
                    <a href="#" class="mobilemenu-toggle"></a>
                </div>
                <div class="mobilemenu-content">
                    <ul class="nav">
                        <li><a href="./">HOME</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="all-product.php">Products</a><span class="arrow"></span>
                        <li><a href="javascript:void();">Category</a><span class="arrow"></span>
                            <ul>
                                <?php
                                $mcategoryall = $pdo->prepare("select * from tbl_category where activatedstatus = 1");
                                $mcategoryall->execute();
                                $mcategory = $mcategoryall->fetchAll();
                                foreach ($mcategory as $mcate) {
                                    ?>
                                    <li>
                                        <a href="javascript:void();" title=""><?php echo $mcate['category_name']; ?></a><span class="arrow"></span>
                                        <ul>
                                            <?php
                                            $msubcat = $pdo->prepare("select * from tbl_sub_category where cid=? and activatedstatus = 1");
                                            $msubcat->bindParam(1, $mcate['cid']);
                                            $msubcat->execute();
                                            $msubcate = $msubcat->fetchAll();
                                            foreach ($msubcate as $msubctg) {
                                                ?>
                                                <li> <a href="product.php?product=<?php echo $msubctg['alias'] ?>" title=""><?php echo $msubctg['sub_category_name'] ?></a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                <?php } ?>
                            </ul>
                        </li>
                        <li><a href="special-offers.php">Special Offers</a></li>
                        <li><a href="contact.php">Contact Us</a></li>
                    </ul>
                </div>
            </div>
            <!-- Mobile Menu -->
            <!-- Mega Menu -->
            <div class="megamenu fadein blackout">							
                <ul class="nav">
                    <li><a href="./" title=""><i class="icon icon-home"></i></a></li>
                    <li class="mega-dropdown">
                        <a href="about.php">About Us</a>
                    </li>
                    <li class="mega-dropdown">
                        <a href="all-product.php">Product</a>
                    </li>
                    <li class="simple-dropdown">
                        <a href="javascript:void();" title="">Category</a>

                        <div class="sub-menu">
                            <ul class="category-links">
                                <?php
                                $categoryall = $pdo->prepare("select * from tbl_category where activatedstatus = 1");
                                $categoryall->execute();
                                $category = $categoryall->fetchAll();
                                foreach ($category as $cate) {
                                    ?>
                                    <li>
                                        <a href="#" title=""><?php echo $cate['category_name']; ?></a><span class="arrow"></span>
                                        <ul>
                                            <?php
                                            $subcat = $pdo->prepare("select * from tbl_sub_category where cid=? and activatedstatus = 1");
                                            $subcat->bindParam(1, $cate['cid']);
                                            $subcat->execute();
                                            $subcate = $subcat->fetchAll();
                                            foreach ($subcate as $subctg) {
                                                ?>
                                                <li> <a href="product.php?product=<?php echo $subctg['alias'] ?>" title=""><?php echo $subctg['sub_category_name'] ?></a></li>
                                            <?php } ?>
                                        </ul>
                                    </li>
                                <?php } ?>

                            </ul>
                        </div>
                    </li>
                    <li class="mega-dropdown">
                        <a href="special-offers.php">Special Offers</a>
                    </li>

                    <li class="simple-dropdown">
                        <a href="contact.php" title="">Contact Us</a>
                    </li>
                </ul>
            </div>
            <!-- /Mega Menu -->
        </div>
    </div>
</header>
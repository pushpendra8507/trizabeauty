<?php $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>
<meta name="author" content="<?php echo isset($url)?$url:'' ?>" />
<meta name="robots" content="index, follow" />
<meta name="rating" content="safe for kids" />
<meta name="googlebot" content=" index, follow" />
<meta name="allow-search" content="yes" />
<meta name="revisit-after" content="daily" />
<meta name="language" content="en-US" />
<meta name="distribution" content="global" />
<link rel="canonical" href="<?php echo isset($url)?$url:'' ?>" />

 <link rel="shortcut icon" href="images/fevi.png">
		


        <!-- Vendor -->
        <link href="js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
        <link href="js/vendor/slick/slick.css" rel="stylesheet">
        <link href="js/vendor/swiper/swiper.min.css" rel="stylesheet">
        <link href="js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
        <link href="js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">
    <!-- Custom -->
        <link href="css/style.css" rel="stylesheet">
        <link href="css/megamenu.css" rel="stylesheet">
        <link href="fonts/icomoon-reg/style.css" rel="stylesheet">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700Raleway:100,100i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900iRoboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

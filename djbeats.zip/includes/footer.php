    <!-- Footer -->
                <footer class="page-footer variant4 fullboxed">

                    <div class="footer-middle">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-3 col-lg-3">
                                    <div class="footer-block collapsed-mobile">
                                        <div class="title">
                                            <h4>INFORMATION</h4>
                                            <div class="toggle-arrow"></div>
                                        </div>
                                        <div class="collapsed-content">
                                            <ul class="marker-list">
                                                <li><a href="about.php">About Us</a></li>
                                                <li><a href="#">Privacy Policy</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-lg-3">
                                    <div class="footer-block collapsed-mobile">
                                        <div class="title">
                                            <h4>MY ACCOUNT</h4>
                                            <div class="toggle-arrow"></div>
                                        </div>
                                        <div class="collapsed-content">
                                            <ul class="marker-list">
                                                <?php if(isset($_SESSION['myemail'])){ ?>
                                                <li><a href="my-account.php?myaccount=<?php echo $_SESSION['myemail'] ?>">My account</a></li>
                                                <?php }else{ ?>
                                                <li><a href="account-create.php">New account</a></li>
                                               <?php } ?>
                                                <li><a href="cart.php">My cart</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-lg-3">
                                    <div class="footer-block collapsed-mobile">
                                        <div class="title">
                                            <h4>CUSTOMER CARE</h4>
                                            <div class="toggle-arrow"></div>
                                        </div>
                                        <div class="collapsed-content">
                                            <ul class="marker-list">
                                                <li><a href="contact.php">Contact Us</a></li>
                                                <li><a href="#">Customer Service</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-lg-3">
								<div class="footer-block collapsed-mobile">
									<div class="title">
										<h4>CONTACT US</h4>
										<div class="toggle-arrow"></div>
									</div>
									<div class="collapsed-content">
										<ul class="simple-list">
                                            <li><i class="icon icon-phone"></i><a href="tel:3139656620">(313) 965-6620</a></li>
											<li><i class="icon icon-close-envelope"></i><a href="mailto:msumareh110@gmail.com">msumareh110@gmail.com</a></li>
										</ul>
										<div class="footer-social">
											<a href="#"><i class="icon icon-facebook-logo icon-circled"></i></a> <a href="#"><i class="icon icon-twitter-logo icon-circled"></i></a>  
										</div>
									</div>
								</div>
							</div>
                            </div>
                        </div>
                    </div>
                    <div class="footer-bot">
                        <div class="container">
                            <div class="row">
                                <div class=" col-md-6 col-lg-6">
                                    <div class="footer-copyright"> © 2020-2023 Djenne Beads & Gem. All Rights Reserved.<br>
                                        <a target="_blank" href="http://wxperts.co/"><img src="images/wxperts_powerdby.jpg" alt="wxperts.co"></a></div>
                                </div>
                    
                                <div class=" col-md-6 col-lg-6">
                    
                                    <div class="footer-payment-link">
                                        <h4>We Accept</h4>
                                        <a href="#"><img src="images/payment-logo/icon-pay-1.png" alt="online-payment"></a>
                                        <a href="#"><img src="images/payment-logo/icon-pay-2.png" alt="online-payment"></a>
                                        <a href="#"><img src="images/payment-logo/icon-pay-3.png" alt="online-payment"></a>
                                        <a href="#"><img src="images/payment-logo/icon-pay-4.png" alt="online-payment"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
         
                </footer>
                <!-- /Footer -->
                <a class="back-to-top back-to-top-mobile" href="#">
                    <i class="icon icon-angle-up"></i> To Top
                </a>
            </div>
            <!-- /Page -->
        </div>

        <!-- Modal Quick View -->
        <div class="modal quick-view zoom" id="quickView">
            <div class="modal-dialog">
                <div class="modalLoader-wrapper">
                    <div class="modalLoader bg-striped"></div>
                </div>
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">&#10006;</button>
                </div>
                <div class="modal-content">
                    <iframe></iframe>
                </div>
            </div>
        </div>
        <!-- /Modal Quick View -->

        <!-- jQuery Scripts  -->
        <script src="js/vendor/jquery/jquery.js"></script>
        <script src="js/vendor/bootstrap/bootstrap.min.js"></script>
        <script src="js/vendor/swiper/swiper.min.js"></script>
        <script src="js/vendor/slick/slick.min.js"></script>
       <script src="js/vendor/isotope/isotope.pkgd.min.js"></script>
        <script src="js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
        <script src="js/vendor/ez-plus/jquery.ez-plus.js"></script>
       <script src="js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
        <script src="js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
        <script src="js/megamenu.min.js"></script>
       <script src="js/app.js"></script>
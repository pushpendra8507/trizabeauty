<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';
if (isset($_REQUEST['view']) && !empty($_REQUEST['view'])) {
    $vdetils = $pdo->prepare("Select * from tbl_product where alias = ? and activatedstatus = 1");
    $vdetils->bindParam(1, $_REQUEST['view']);
    $vdetils->execute();
    $detail = $vdetils->fetch();

    $pcolor = $detail['color'];
    $prod_color = explode(',', $pcolor);
    $color_count = count($prod_color);
}

$size = $pdo->prepare("select * from tbl_product_size where pid=?");
$size->bindParam(1, $detail['pid']);
$size->execute();
$vsiz = $size->fetch();
$size1 = sanetize($vsiz['size1']);
$size2 = sanetize($vsiz['size2']);
$size3 = sanetize($vsiz['size3']);
$size4 = sanetize($vsiz['size4']);
$size5 = sanetize($vsiz['size5']);
$size6 = sanetize($vsiz['size6']);
$size7 = sanetize($vsiz['size7']);
$size8 = sanetize($vsiz['size8']);
$size9 = sanetize($vsiz['size9']);
$size10 = sanetize($vsiz['size10']);

if (isset($_POST['addToCart'])) {
    $pid = $_POST['pid'];
    $prodt = $pdo->prepare("Select * from tbl_product where pid=?");
    $prodt->bindParam(1, $pid);
    $prodt->execute();
    $pdetls = $prodt->fetch();
    $sprice = special_price($pid);
    $price = (isset($pdetls['discount']) && !empty($pdetls['discount'])) ? $sprice : $pdetls['price'];
    $quantity = $_POST['quantity'];
    $size = $_POST['size'];
    $color = $_POST['color'];

    addToCart($pid, $quantity, $price, $size, $color);
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Buy Kirdi Beaded Cache Sexe Pikuran Cameroon African Art</title>
        <meta name="Description" content="Discover the cultural heritage of Cameroon with Kirdi beaded Cache Sexe Pikuran at Djenne Beads & Gem. Authentic African art awaits you"/>
		<meta name="Keywords" content="Kirdi Beaded Cache Sexe Detroit, MI, Kirdi Beaded Cache Sexe Pikuran Cameroon African Art, Cache Sexe, African Amber Beads for Sale Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">
        <div id="wrapper">
            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->
                <!-- Page Content -->
                <main class="page-main">
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <h1 class="hide">Buy Kirdi Beaded Cache Sexe Pikuran Cameroon African Art</h1>
                                <h2 class="hide">Kirdi Beaded Cache Sexe Detroit, MI</h2>
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span><?php echo $detail['name'] ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block product-block">
                        <form method="post" >
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-6 col-md-4 col-lg-3">
                                        <!-- Product Gallery -->
                                        <div class="main-image">
                                            <img src="<?php echo $detail['photourl1'] ?>" class="zoom" alt="" data-zoom-image="<?php echo $detail['photourl1'] ?>" />
											<div class="dblclick-text"><span>Double click for enlarge</span></div>
                                            <a href="<?php echo $detail['photourl1'] ?>" class="zoom-link"></a>
                                        </div>
                                        <div class="product-previews-wrapper">
                                            <div class="product-previews-carousel" id="previewsGallery">
                                                <a href="#" data-image="<?php echo $detail['photourl1'] ?>" data-zoom-image="<?php echo $detail['photourl1'] ?>"><img src="<?php echo $detail['photourl1'] ?>" alt="<?php echo $detail['alt_name1'] ?>" /></a>
                                                <a href="#" data-image="<?php echo $detail['photourl2'] ?>" data-zoom-image="<?php echo $detail['photourl2'] ?>"><img src="<?php echo $detail['photourl2'] ?>" alt="<?php echo $detail['alt_name2'] ?>" /></a>
                                                <a href="#" data-image="<?php echo $detail['photourl3'] ?>" data-zoom-image="<?php echo $detail['photourl3'] ?>"><img src="<?php echo $detail['photourl3'] ?>" alt="<?php echo $detail['alt_name3'] ?>" /></a>

                                            </div>
                                        </div>
                                        <!-- /Product Gallery -->
                                    </div>
                                    <div class="col-sm-6 col-md-8 col-lg-3">
                                        <div class="product-info-block classic">
                                            <div class="product-name-wrapper">
                                                <h3 class="product-name"><?php echo $detail['name'] ?></h3>
                                                <div class="product-labels">
                                                    <?php if (isset($detail['discount']) && !empty($detail['discount'])) { ?>
                                                        <span class="product-label sale">SALE</span>
                                                    <?php } ?>
                                                    <?php if ($detail['pid'] > new_arrival()) { ?>
                                                        <span class="product-label new">NEW</span>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <?php if (stockIn($detail['pid']) < $detail['stock']) { ?>
                                                <div class="product-availability">Availability: <span>In stock</span></div>
                                            <?php } else { ?> 
                                                <div class="product-availability">Availability: <span style="color: #F20;">Out Of stock</span></div>
                                            <?php } ?>
                                            <div class="product-options">
                                                <div class="product-size swatches">
                                                    <span class="option-label">Color:</span>
                                                    <div class="select-wrapper-sm">
                                                        <select class="form-control input-sm size-variants" name="color">
                                                            <option value="">- Color -</option>
                                                            <?php
                                                            $sel_color = "";
                                                            for ($s = 0; $s <= $color_count; $s++) {
                                                                $selected_color = $prod_color[$s];
                                                                $color = $pdo->prepare("select * from tbl_color where status = 1 and id=? ORDER BY title ASC");
                                                                $color->bindParam(1, $prod_color[$s]);
                                                                $color->execute();
                                                                $allcolor = $color->fetchAll();
                                                                foreach ($allcolor as $clr) {
                                                                    ?>
                                                                    <option value="<?php echo $clr['title'] ?>"><?php echo $clr['title'] ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="product-size swatches">
                                                    <span class="option-label">Size:</span>
                                                    <div class="select-wrapper-sm">
                                                        <select class="form-control input-sm size-variants" name="size">
                                                            <option value="">- Size -</option>
                                                            <?php
                                                            if (!empty($size1) || (!empty($size2)) || (!empty($size3)) || (!empty($size4)) || (!empty($size5)) || (!empty($size6)) || (!empty($size7)) || (!empty($size8)) || (!empty($size9)) || (!empty($size10))) {
                                                                if (!empty($size1)) {
                                                                    ?>
                                                                    <option value="<?php echo $size1; ?>"><?php echo $size1; ?></option>
                                                                    <?php
                                                                }if (!empty($size2)) {
                                                                    ?>
                                                                    <option value="<?php echo $size2; ?>"><?php echo $size2; ?></option>
                                                                    <?php
                                                                } if (!empty($size3)) {
                                                                    ?>
                                                                    <option value="<?php echo $size3; ?>"><?php echo $size3; ?></option>
                                                                    <?php
                                                                } if (!empty($size4)) {
                                                                    ?>
                                                                    <option value="<?php echo $size4; ?>"><?php echo $size4; ?></option>
                                                                    <?php
                                                                } if (!empty($size5)) {
                                                                    ?>
                                                                    <option value="<?php echo $size5; ?>"><?php echo $size5; ?></option>
                                                                    <?php
                                                                }if (!empty($size6)) {
                                                                    ?>
                                                                    <option value="<?php echo $size6; ?>"><?php echo $size6; ?></option>
                                                                    <?php
                                                                }if (!empty($size7)) {
                                                                    ?>
                                                                    <option value="<?php echo $size7; ?>"><?php echo $size7; ?></option>
                                                                    <?php
                                                                }if (!empty($size8)) {
                                                                    ?>
                                                                    <option value="<?php echo $size8; ?>"><?php echo $size8; ?></option>
                                                                    <?php
                                                                }if (!empty($size9)) {
                                                                    ?>
                                                                    <option value="<?php echo $size9; ?>"><?php echo $size9; ?></option>
                                                                    <?php
                                                                }if (!empty($size10)) {
                                                                    ?>
                                                                    <option value="<?php echo $size10; ?>"><?php echo $size10; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>

                                                        </select>
                                                    </div>

                                                </div>

                                                <div class="product-qty">
                                                    <span class="option-label">Qty:</span>
                                                    <div class="qty qty-changer">
                                                        <fieldset>
                                                            <input type="button" value="‒" class="decrease">
                                                            <input type="text" name="quantity" class="qty-input" value="1" maxlength="3" data-min="1" required="" onkeypress="return isNumberKey(event)">
                                                            <input type="button" value="+" class="increase">
                                                        </fieldset>
                                                    </div>
                                                </div>
                                                <div class="price-details">
                                                    <span class="option-label">Price:</span>
                                                    <?php
                                                    $sprice = special_price($detail['pid']);
                                                    if (isset($detail['discount']) && !empty($detail['discount'])) {
                                                        ?>
                                                        <div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"><?php echo '$' . number_format($detail['price'], 2) ?></span> <span class="special-price"><?php echo '$' . number_format($sprice, 2) ?></span> </span></span> </div>
                                                    <?php } else { ?>
                                                        <div class="price-box"> <span class="price-container"> <span class="price-wrapper"><span class="special-price"><?php echo '$' . number_format($detail['price'], 2) ?></span> </span></span> </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-sm-6 col-md-8 col-lg-6">
                                        <div class="block">
                                            <div class="tabaccordion">
                                                <div class="container">
                                                    <!-- Nav tabs -->
                                                    <ul class="nav-tabs product-tab" role="tablist">
                                                        <li><a href="#Tab1" role="tab" data-toggle="tab">Description</a></li>
                                                    </ul>
                                                    <!-- Tab panes -->
                                                    <div class="tab-content">
                                                        <div role="tabpanel" class="tab-pane" id="Tab1">
                                                            <?php echo html_entity_decode($detail['description']) ?>
                                                        </div>
                                                    </div>
                                                    <div class="product-actions">
                                                        <div class="row">
                                                            <div class="col-md-6">
                                                                <?php if (stockIn($detail['pid']) < $detail['stock']) { ?>
                                                                    <div class="actions">
                                                                        <input type="hidden" name="pid" value="<?php echo $detail['pid'] ?>">
                                                                        <button type="submit" name="addToCart" class="btn btn-lg btn-loading"><i class="icon icon-cart"></i><span>Add to cart</span></button>
                                                                    </div>
                                                                <?php } ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </main>
                <!-- /Page Content -->
                
           <?php include("includes/footer.php"); ?>
            <script>
                function isNumberKey(evt) {
                    var charCode = (evt.which) ? evt.which : event.keyCode
                    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                        return false;
                    } else {
                        return true;
                    }
                }
                
        </script>
    </body>
</html>
               
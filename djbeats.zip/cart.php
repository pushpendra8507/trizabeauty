<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

$cartprd = $pdo->prepare("Select tbl_tempcart.*, tbl_tempcart.price as cart_price, tbl_product.* from tbl_tempcart left join tbl_product on tbl_tempcart.pid = tbl_product.pid where ssn_tmp=? order by cart_id");
$cartprd->bindParam(1, $_SESSION['ssn_tmp']);
$cartprd->execute();
$cartAll = $cartprd->fetchAll();

$decrease = $pdo->prepare("Select tbl_tempcart.*, tbl_tempcart.price as cart_price, tbl_product.* from tbl_tempcart left join tbl_product on tbl_tempcart.pid = tbl_product.pid where ssn_tmp=?");
$decrease->bindParam(1, $_SESSION['ssn_tmp']);
$decrease->execute();
$decreaseAll = $decrease->fetchAll();

$increase = $pdo->prepare("Select tbl_tempcart.*, tbl_tempcart.price as cart_price, tbl_product.* from tbl_tempcart left join tbl_product on tbl_tempcart.pid = tbl_product.pid where ssn_tmp=?");
$increase->bindParam(1, $_SESSION['ssn_tmp']);
$increase->execute();
$increaseAll = $increase->fetchAll();

if (isset($_REQUEST['delete']) && !empty($_REQUEST['delete'])) {
    $del_id = sanetize($_REQUEST['delete']);
    $delete = $pdo->prepare("delete from tbl_tempcart where cart_id=?");
    $delete->bindParam(1, $del_id);
    $delete->execute();
    header("location:cart.php");
}

if (isset($_POST['continue'])) {
    header("location:all-product.php");
}

if (isset($_POST['clearAll'])) {
    $clearAll = $pdo->prepare("delete from tbl_tempcart where ssn_tmp=?");
    $clearAll->bindParam(1, $_SESSION['ssn_tmp']);
    $clearAll->execute();
    header("location:cart.php");
}

if (isset($_POST['cart_id'])) {
    $qty_cart = sanetize($_POST['cart_id']);
    $quantity = sanetize($_POST['quantity']);
    $update = $pdo->prepare("update tbl_tempcart set quantity=? where cart_id=?");
    $update->bindParam(1, $quantity);
    $update->bindParam(2, $qty_cart);
    $update->execute();
    header('location:cart.php');
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cart | Djenne Beads & Gem Detroit, MI | Maasai Beads</title>
        <meta name="Description" content="Fill your cart with authentic Maasai beads from Djenne Beads & Gem in Detroit, MI. Explore our vibrant collection of African trade beads today"/>
		<meta name="Keywords" content="Djenne Beads & Gem Detroit, MI, Kirdi Beaded Cache Sexe Detroit, MI, Djenne Beads & Gem, Maasai Beaded Necklace Detroit, MI, Tuareg Wood Bowl Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">


        <div id="wrapper">
            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->

                <main class="page-main">
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <h1 class="hide">Cart Buy Djenne Beads & Gem Detroit, MI</h1>
                                <h2 class="hide">Cart BuyMaasai Beads</h2>
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span>Shopping Cart</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block">
                        <?php if ($cartprd->rowCount() > 0) { ?>
                            <div class="container">
                                <div class="cart-table">
                                    <div class="table-header">
                                        <div class="photo">
                                            Product Image
                                        </div>
                                        <div class="name">
                                            Product Name
                                        </div>
                                        <div class="price">
                                            Unit Price
                                        </div>
                                        <div class="qty">
                                            Qty
                                        </div>
                                        <div class="subtotal">
                                            Subtotal
                                        </div>
                                        <div class="remove">
                                            <span class="hidden-sm hidden-xs">Remove</span>
                                        </div>
                                    </div>
                                    <?php
                                    foreach ($cartAll as $cart) {
                                        $price = $cart['cart_price'];
                                        $quantity = $cart['quantity'];
                                        $subtotal = $price * $quantity;
                                        ?>
                                        <div class="table-row">
                                            <div class="photo">
                                                <a href="product-detail.php?view=<?php echo $cart['alias'] ?>&<?php echo $cart['alt_name1'] ?>&#imgwrap"><img src="<?php echo $cart['photourl1'] ?>" alt="<?php echo $cart['alt_name1'] ?>"></a>
                                            </div>
                                            <div class="name">
                                                <a href="product-detail.php?view=<?php echo $cart['alias'] ?>&<?php echo $cart['alt_name1'] ?>&#imgwrap"><?php echo $cart['name'] ?></a>
                                            </div>
                                            <div class="price">
                                                <?php echo '$' . $price ?>
                                            </div>

                                            <div class="qty qty-changer">
                                                <fieldset>
                                                    <form method="post">
                                                        <input type="hidden" name="cart_id" id="cart_id<?php echo $cart['cart_id'] ?>" value="<?php echo $cart['cart_id'] ?>">
                                                        <input type="button" value="-" class="decrease" id="decrease<?php echo $cart['cart_id'] ?>">
                                                        <input type="text" name="quantity" id="quantity" class="qty-input" value="<?php echo $quantity ?>" data-min="1" maxlength="3" data-min="1" required="" onkeypress="return isNumberKey(event)" onchange="submit();">
                                                        <input type="button" value="+" class="increase" id="increase<?php echo $cart['cart_id'] ?>">
                                                    </form>
                                                </fieldset>
                                            </div>
                                            <div class="subtotal">
                                                <?php echo '$' . $subtotal ?>
                                            </div>
                                            <div class="remove">
                                                <a href="cart.php?delete=<?php echo $cart['cart_id'] ?>&#imgwrap" class="icon icon-close-2"></a>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div class="table-footer">
                                        <form method="post">
                                            <button type="submit" name="continue" class="btn btn-alt">CONTINUE SHOPPING</button>
                                            <button type="submit" name="clearAll" class="btn btn-alt pull-right"><i class="icon icon-bin"></i><span>Clear Shopping Cart</span></button>
                                        </form>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3 total-wrapper">
                                        <table class="total-price">
    <!--                                        <tr>
                                                <td>Subtotal</td>
                                                <td>$241.00</td>
                                            </tr>
                                            <tr>
                                                <td>Discount</td>
                                                <td>$12.00</td>
                                            </tr>-->
                                            <tr class="total">
                                                <td>Grand Total</td>
                                                <td><?php echo '$' . cartTotal(); ?></td>
                                            </tr>
                                        </table>
                                        <div class="cart-action">
                                            <?php if (restrict_user_entry() == 1) { ?>
                                                <div>
                                                    <a href="checkout.php" class="btn">Proceed To Checkout</a>
                                                </div>
                                            <?php }else{ ?>
                                                <div>
                                                    <a href="checkout.php" class="btn">Checkout As Guest</a>
                                                </div>
                                           <?php } ?>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php } else {
                            ?>
                            <div class="table-footer">
                                <center><h2>No Item In Cart</h2></center>
                                <form method="post">
                                    <button type="submit" name="continue" class="btn btn-alt">CONTINUE SHOPPING</button>
                                </form>
                            </div>
                        <?php }
                        ?>
                    </div>
                </main>
                <!-- /Page Content -->
                
                    <?php include("includes/footer.php"); ?>
                     <script>
                                                    function isNumberKey(evt) {
                                                        var charCode = (evt.which) ? evt.which : event.keyCode
                                                        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                                                            return false;
                                                        } else {
                                                            return true;
                                                        }
                                                    }
        </script>
        <?php foreach ($increaseAll as $add) { ?>
            <script>
                $(document).ready(function (e) {
                    $("#increase<?php echo $add['cart_id'] ?>").click(function () {

                        var text = $('#cart_id<?php echo $add['cart_id'] ?>').val();
                        $.ajax({
                            type: 'GET',
                            url: 'quantity-increase.php',
                            data: 'cart_id=' + text,
                            success: function (data) {
                                location.reload(data);
                            }
                        });
                    })
                });
            </script>
        <?php } ?>
        <?php foreach ($decreaseAll as $mins) { ?>
            <script>
                $(document).ready(function (e) {
                    $("#decrease<?php echo $mins['cart_id'] ?>").click(function () {

                        var text = $('#cart_id<?php echo $mins['cart_id'] ?>').val();
                        $.ajax({
                            type: 'GET',
                            url: 'quantity-decrease.php',
                            data: 'cart_id=' + text,
                            success: function (data) {
                                location.reload(data);
                            }
                        });
                    })
                });
            </script>
        <?php } ?>
    </body>
</html>
          
          
          
          
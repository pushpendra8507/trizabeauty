<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

$qty_cart = $_GET['cart_id'];

$update = $pdo->prepare("update tbl_tempcart set quantity=quantity+ 1 where cart_id=?");
$update->bindParam(1, $qty_cart);
$update->execute();
?>

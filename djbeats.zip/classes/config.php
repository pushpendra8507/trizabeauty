<?php
date_default_timezone_set("America/Los_Angeles");

if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1') {
    //Local Connection
   $hostname = 'localhost';
    $username = 'djennebe_bed';
    $password = 'LgsIbXq%o6xb';
    $db_name = 'djennebe_bed';
} else {
    //Global Connection
    $hostname = 'localhost';
    $username = 'djennebe_bed';
    $password = 'LgsIbXq%o6xb';
    $db_name = 'djennebe_bed';
}

$dsn = "mysql:host=$hostname;dbname=$db_name;charset=utf8mb4";

$pdo = new PDO($dsn, $username, $password);


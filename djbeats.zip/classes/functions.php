<?php

error_reporting(0);
session_start();
include_once 'config.php';

function custom_echo($x, $length) {
    if (strlen($x) <= $length) {
        echo $x;
    } else {
        $y = substr($x, 0, $length) . '... ';
        echo $y;
    }
}

if (!function_exists('hash_equals')) {

    function hash_equals($str1, $str2) {
        if (strlen($str1) != strlen($str2)) {
            return false;
        } else {
            $res = $str1 ^ $str2;
            $ret = 0;
            for ($i = strlen($res) - 1; $i >= 0; $i--) {
                $ret |= ord($res[$i]);
            }
            return !$ret;
        }
    }

}

function csrf_token() {
    //$_SESSION['token'] = bin2hex(random_bytes(32));
    $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(32));
    $token = $_SESSION['token'];
    return $token;
}

function verify_token($token_s) {
    if (hash_equals($_SESSION['token'], $token_s)) {
        $token = 'yes';
        return $token;
    } else {
        $token = 'no';
        return $token;
    }
}

function setSession_value($id) {
    global $pdo;
    $stmt = $pdo->prepare("select * from tbl_user where uid=?");
    $stmt->bindParam(1, $id);
    $stmt->execute();
    $data = $stmt->fetch();
    $_SESSION['myemail'] = $data['email'];
    $_SESSION['myuid'] = $data['uid'];
}

function check_login($email, $password) {
    global $pdo;
    $stmt = $pdo->prepare("select * from tbl_user where BINARY email=? and BINARY password=? and activatedstatus = 1");
    $stmt->bindParam(1, $email);
    $stmt->bindParam(2, $password);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $data = $stmt->fetch();
        setSession_value($data['uid']);
        return '1'; //login valid
    } else {
        return '0'; //invalid login
    }
}

function user_logout() {
    unset($_SESSION['myemail']);
    unset($_SESSION['myuid']);
    header("location:./");
}

function special_price($product_id) {
    global $pdo;
    $product = $pdo->prepare("Select * from tbl_product where pid=?");
    $product->bindParam(1, $product_id);
    $product->execute();
    $prdt = $product->fetch();
    $price = $prdt['price'];
    $discount = $prdt['discount'];
    $dprice = (($price * $discount) / 100);
    $sprice = $price - $dprice;
    return $sprice;
}

function new_arrival() {
    global $pdo;
    $product = $pdo->prepare("SELECT pid from tbl_product ORDER by pid DESC limit 8, 1");
    $product->execute();
    $prdt = $product->fetch();
    return $prdt['pid'];
}

function cartCounter() {
    global $pdo;
    $stmt = $pdo->prepare("select * from tbl_tempcart where ssn_tmp=?");
    $stmt->bindParam(1, $_SESSION['ssn_tmp']);
    $stmt->execute();
    $cnt = ($stmt->rowCount() > 0) ? $stmt->rowCount() : 0;
    return $cnt;
}

function cartTotal() {
    global $pdo;
    $stmt = $pdo->prepare("select sum(quantity*price) as amount from tbl_tempcart where ssn_tmp=?");
    $stmt->bindParam(1, $_SESSION['ssn_tmp']);
    $stmt->execute();
    $total = $stmt->fetch();
    $totalamt = ($total['amount'] > 0) ? $total['amount'] : 0;
    return $totalamt;
}

function stockIn($pid) {
    global $pdo;
    $stmt = $pdo->prepare("select sum(quantity) as stock from tbl_order_details where pid=?");
    $stmt->bindParam(1, $pid);
    $stmt->execute();
    $total = $stmt->fetch();
    $totalstock = ($total['stock'] > 0) ? $total['stock'] : 0;
    return $totalstock;
}

function addToCart($product, $quantity, $price, $size, $color) {
    global $pdo;
    if (!isset($_SESSION['ssn_tmp'])) {

        $_SESSION['ssn_tmp'] = date('YmdHis') . rand(0000000000000, 9999999999999);
        $session = $pdo->prepare("INSERT INTO tbl_ssn_tmp( ssn_tmp, activatedstatus) values (?, 1)") or die('session table does not exist');
        $session->bindParam(1, $_SESSION['ssn_tmp']);
        $session->execute();

        $temcart = $pdo->prepare("select * from tbl_tempcart where pid=? and ssn_tmp=?");
        $temcart->bindParam(1, $product);
        $temcart->bindParam(2, $_SESSION['ssn_tmp']);
        $temcart->execute();

        $insert = $pdo->prepare("Insert into tbl_tempcart (ssn_tmp, pid, price, quantity, size, color, activatedstatus) values(?, ?, ?, ?, ?, ?, 1)");
        $insert->bindParam(1, $_SESSION['ssn_tmp']);
        $insert->bindParam(2, $product);
        $insert->bindParam(3, $price);
        $insert->bindParam(4, $quantity);
        $insert->bindParam(5, $size);
        $insert->bindParam(6, $color);
        $insert->execute();
    } else {
        $temcart = $pdo->prepare("select * from tbl_tempcart where pid=? and ssn_tmp=?");
        $temcart->bindParam(1, $product);
        $temcart->bindParam(2, $_SESSION['ssn_tmp']);
        $temcart->execute();

        $insert = $pdo->prepare("Insert into tbl_tempcart (ssn_tmp, pid, price, quantity, size, color, activatedstatus) values(?, ?, ?, ?, ?, ?, 1)");
        $insert->bindParam(1, $_SESSION['ssn_tmp']);
        $insert->bindParam(2, $product);
        $insert->bindParam(3, $price);
        $insert->bindParam(4, $quantity);
        $insert->bindParam(5, $size);
        $insert->bindParam(6, $color);
        $insert->execute();
    }
}

function restrict_user_entry() {
    if (!isset($_SESSION['myemail']) && !isset($_SESSION['myuid'])) {
        $_SESSION['checkout'] = 'yes';
        return '0';
    } else {
        return '1';
    }
}

function send_mail($orderid, $email) {
    global $pdo;
    $stmh = $pdo->prepare("select * from tbl_order where odr_id=?");
    $stmh->bindParam(1, $orderid);
    $stmh->execute();
    $shipto = $stmh->fetch();

    $ordd = $pdo->prepare("select tbl_order_details.*, tbl_order_details.price as order_price, tbl_product.name from tbl_order_details left join tbl_product on tbl_order_details.pid=tbl_product.pid where tbl_order_details.odr_id=?");
    $ordd->bindParam(1, $orderid);
    $ordd->execute();
    $oddr = $ordd->fetchAll();

    $to = $email . ",msumareh110@gmail.com,info@wserve.com";
    //$to = $email . ',ram.sharan@wserve.com';
    $subject = "Order Invoice";
    $message = '<!DOCTYPE HTML>
        <html><head><title>Order Detail</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
		<table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">
		
	<tr bgcolor="#fff" valign="top">
		  <td height="25"  colspan="2" style="font:bold 21px  Arial, Helvetica, sans-serif; color:#fff"><img src="http://www.djennebeads.com/images/logo.png" class="img-responsive" alt="djennebeads"> </td>
		</tr>
		</table>
        <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
        <tbody>
           <tr>
            <td width="100%" valign="top">
                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                    <tbody>		
                       <tr bgcolor="#09649e">
                        <td  class="billing_hd" style="color:#FFF"><strong>Order Number:  ' . $shipto['order_number'] . '</strong></td>
                        <td  class="billing_hd" style="color:#FFF"><strong>Date:  ' . date('m/d/Y H:i:s', strtotime($shipto['order_date'])) . '</strong></td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd" colspan="2">Shipping Details:</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Name :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_name'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Email :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_email'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Phone :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_phone'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Street Address :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_street'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> City :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_city'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> State :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_state'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Zipcode :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_zipcode'] . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Country :</td>
                            <td width="70%" class="ship_hd"> ' . $shipto['ship_country'] . '</td>
                        </tr>
                        
                        <tr>
                            <table>
                                <thead>
                                    <tr>
                                        <td>Product Name</td>
                                        <td>Quantity</td>
                                        <td>Size</td>
                                        <td>Color</td>
                                        <td>Price</td>
                                        <td>Subtotal</td>
                                    </tr>
                                </thead>
                                <tbody>';

    foreach ($oddr as $opm) {
        $prod_name = $opm['name'];
        $qnty = $opm['quantity'];
        $prc = $opm['order_price'];
        $size = $opm['quantity'];
        $color = $opm['quantity'];
        $subtotal = $qnty * $prc;
        $message .= '<tr>
                        <td width="25%" class="ship_hd">' . $prod_name . '</td>
                        <td width="25%" class="ship_hd">' . $qnty . '</td>
                        <td width="25%" class="ship_hd">' . $size . '</td>
                        <td width="25%" class="ship_hd">' . $color . '</td>
                        <td width="25%" class="ship_hd">' . $prc . '</td>
                        <td width="25%" class="ship_hd">' . $subtotal . '</td>
                    </tr>';
    }
    $message .= '</tbody>
                   <tr>
                        <td colspan="4">Total Amount</td>
                        <td>$' . $shipto['total_amount'] . '</td>
                    </tr></table>
                     </tr>
                     </table>
		</td>
		</tr></tbody>
  </table>
  </div></body></html>';
    $fromName = 'Djenne Beads & Gem';
    $fromMail = 'info@djennebeads.com';
    $headers = 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $headers .= 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
    $message = str_replace("\'", "'", $message);
    //echo $message;exit;
    mail($to, $subject, $message, $headers);
}

function sanetize($string) {
    $string = str_replace('"', '', $string);
    $string = str_replace("'", '', $string);
    $string = htmlspecialchars($string);
    return $string;
}

function clean_url($string) {
    $string = str_replace(array('[\', \']'), '', $string);
    $string = preg_replace('/\[.*\]/U', '', $string);
    $string = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $string);
    $string = htmlentities($string, ENT_COMPAT, 'utf-8');
    $string = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i', '\\1', $string);
    $string = preg_replace(array('/[^a-z0-9]/i', '/[-]+/'), ' ', $string);
    return strtolower(trim($string, '-'));
}

?>

<?php
session_start();
error_reporting(0);
include_once 'config.php';
/* @var $pdo PDO */

function ValidateLogin($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("Select * from tbl_admin where BINARY  username=? and BINARY password=? And activatedstatus=1");
    $stmt->bindParam(1, $username);
    $stmt->bindParam(2, $password);
    $stmt->execute();
    if ($stmt->rowcount() == 0) {
        return '0';
    } else {
        $rs = $stmt->fetch();
        $_SESSION["admin"] = $rs["aid"];
        $_SESSION["email"] = $rs["username"];
        return '1';
    }
}

function UploadImage($fname, $folder, $upname, $tbl, $field, $updatefield, $id) {
    global $pdo;
    //print_r($fname);exit;
    $type = $fname["type"];
    $fname1 = $fname["name"];
    $path_info = pathinfo($fname1);
    $path_info['extension'];
    $ext = '.' . $path_info['extension'];
    if (($type = "image/jpg" || $type = "image/jpeg" || $type = "image/png" || $type = "image/bmp" || $type = "image/gif")) {
        $pathv = $folder . $upname . $ext;
        move_uploaded_file($fname["tmp_name"], '../' . $folder . $upname . $ext);
        $stmt = $pdo->prepare("update $tbl set $field=? where $updatefield=?");
        $stmt->bindParam(1, $pathv);
        $stmt->bindParam(2, $id);
        $stmt->execute();
    }
}

function change_password($old_pass, $new_pass) {
    global $pdo;
    $stmt = $pdo->prepare("select * from tbl_admin where username=? and BINARY password=?");
    $stmt->bindParam(1, $_SESSION['email']);
    $stmt->bindParam(2, $old_pass);
    $stmt->execute();
    if ($stmt->rowCount() > 0) {
        $stm = $pdo->prepare("Update tbl_admin set password=? where user_id=?");
        $stm->bindParam(1, $new_pass);
        $stm->bindParam(2, $_SESSION['admin']);
        $stm->execute();
        return '1'; // valid user
    } else {
        return '0'; //invalid user
    }
}

function sanetize($string) {
    $string = str_replace('"', '', $string);
    $string = str_replace("'", '', $string);
    $string = htmlspecialchars($string);
    return $string;
}

function custom_echo($x, $length) {
    if (strlen($x) <= $length) {
        echo $x;
    } else {
        $y = substr($x, 0, $length) . '...';
        echo $y;
    }
}

if (!function_exists('hash_equals')) {

    function hash_equals($str1, $str2) {
        if (strlen($str1) != strlen($str2)) {
            return false;
        } else {
            $res = $str1 ^ $str2;
            $ret = 0;
            for ($i = strlen($res) - 1; $i >= 0; $i--) {
                $ret |= ord($res[$i]);
            }
            return !$ret;
        }
    }

}

function csrf_token() {
    //$_SESSION['token'] = bin2hex(random_bytes(32));
    $_SESSION['token'] = bin2hex(openssl_random_pseudo_bytes(32));
    $token = $_SESSION['token'];
    return $token;
}

function verify_token($token_s) {
    if (hash_equals($_SESSION['token'], $token_s)) {
        $token = 'yes';
        return $token;
    } else {
        $token = 'no';
        return $token;
    }
}

function alias_url($string) {
    $string = str_replace(array('[\', \']'), '', $string);
    $string = preg_replace('/\[.*\]/U', '', $string);
    $string = preg_replace('/&(amp;)?#?[a-z0-9]+;/i', '-', $string);
    $string = htmlentities($string, ENT_COMPAT, 'utf-8');
    $string = preg_replace('/&([a-z])(acute|uml|circ|grave|ring|cedil|slash|tilde|caron|lig|quot|rsquo);/i',
            '\\1', $string);
    $string = preg_replace(array('/[^a-z0-9]/i', '/[-]+/'), '-', $string);
    return strtolower(trim($string, '-'));
}
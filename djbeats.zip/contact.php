<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

if (isset($_POST['submit'])) {
    if (isset($_POST['name'])) {
        if (strlen(trim($_POST['name'])) <= 0) {
            echo '<script>alert("User Name should not be empty!.");window.location="contact.php"</script>';
            exit;
        }
    }
    if (isset($_POST['email'])) {
        if (strlen(trim($_POST['email'])) <= 0) {
            echo '<script>alert("Email should not be empty!.");window.location="contact.php"</script>';
            exit;
        }
    }

    if (isset($_POST['message'])) {
        if (strlen(trim($_POST['message'])) <= 0) {
            echo '<script>alert("Message should not be empty!.");window.location="contact.php"</script>';
            exit;
        }
    }

    $name = clean_url(sanetize(htmlspecialchars(stripslashes(trim($_POST['name'])))));
    $email = sanetize(htmlspecialchars(stripslashes(trim($_POST['email']))));
    $msge = clean_url(sanetize(htmlspecialchars(stripslashes(trim($_POST['message'])))));

    $restriction = array('sex', 'fuck', 'ass', 'bonk', 'blow', 'lie', 'cryptocurrency', 'web developer', 'developer', 'designer', 'ideas',
        'crypto currency', 'bitcoin', 'website', 'need', 'freelance', 'better', 'previous', 'wont', 'fees', 'CryptoTab',
        'best', 'appreciate', 'cheers', 'sites', ' search engine', 'visitors', 'marketing', 'money', 'users', 'improvements',
        'unlock', 'hot', 'talkwithcustomer', 'traffic', 'work ', 'social media', 'blog', 'liveserveronline', 'buy', 'seo', 'monkeydigital',
        'digital', 'improve', 'offer', 'job', 'sales', 'surfing', 'casino', 'prophecy', 'church', 'indeed', 'god', 'falling', 'Advisors',
        'loan ', 'Eligibility', 'suggest', 'https', 'adultdating', 'dating', '1borsa', 'nuratina', 'links');
    foreach ($restriction as $restrictions) {
        if (stripos($msge, $restrictions) !== false) {
            echo '<script>alert("abusive word found");window.location="contact.php"</script>';
            exit;
        }
    }

    $to = 'msumareh110@gmail.com, info@wserve.com';
    //$to = 'ram.sharan@wserve.com'; // add additional mail receipient here
    $fromMail = $email;
    $fromName = 'Djenne Beads &AMP; Gem';
    $subject = 'New Contact Form';
    $message = '<html><head><title>Djenne Beads &AMP; Gem</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
		<table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">
		
	<tr bgcolor="#09061B" valign="top">
		  <td height="25"  colspan="2" style="font:bold 21px  Arial, Helvetica, sans-serif; color:#ffff"><center>Djenne Beads &AMP; Gem</center></td>
		</tr>
		</table>
        <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
        <tbody>
           <tr>
            <td width="100%" valign="top">
                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                    <tbody>		
                       <tr bgcolor="#000">
                        <td colspan="2" class="billing_hd" style="color:#FFF"><strong>Contact  Form</strong></td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd"> Name:</td>
                            <td width="70%" class="ship_dt">' . $name . '</td>
                        </tr>
                        <tr>
                            <td class="ship_hd">Email:</td>
                            <td class="ship_dt">' . $email . '</td>
                        </tr>
                        <tr>
                            <td width="30%" class="ship_hd">Message:</td>
                            <td width="70%" class="ship_dt">' . $msge . '</td>
                        </tr>
                   </table>
		</td>
		</tr></tbody>
  </table>
  </div></body></html>';
    // To send HTML mail, the Content-type header must be set
    $headers = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";
    $headers .= 'From:' . $fromName . " " . '<' . $fromMail . '>' . "\r\n";
    $message = str_replace("\'", "'", $message);
    //echo $message;exit;
    $send_mail = mail($to, $subject, $message, $headers);

    if ($send_mail) {
        echo '<script>alert("Thank You For Contact Us.");window.location="contact.php"</script>';
    } else {
        echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="contact.php"</script>';
    }
}

$meta_name = $pdo->prepare("select * from tbl_contactus order by ctid ");
$meta_name->execute();
$mname = $meta_name->fetch();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contact Djenne Beads & Gem | African Trade Beads Detroit, MI</title>
        <meta name="Description" content="Discover authentic African trade beads & Maasai beads at Djenne Beads & Gem in Detroit, MI. Explore vibrant colors & intricate designs. Enhance your collection today"/>
		<meta name="Keywords" content="African Trade Beads Detroit, MI, Djenne Beads & Gem, Maasai Beads, Wooden Bowls, Botswana Baskets Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">

        <div class="fixed-btns demo-mode">
            <!-- Back To Top -->
            <a href="#" class="top-fixed-btn back-to-top is-visible"><i class="icon icon-arrow-up"></i></a>
            <!-- /Back To Top -->
        </div>
        <div id="wrapper">

            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->

                <main class="page-main">

                    <div class="block">
                        <div class="container">
                            <div class="title center">
                                <h1 class="hide">Contact Djenne Beads & Gem</h1>
                                <h2 class="hide">Contact</h2>
                                <h3>Contact Us</h3>
                            </div>
                        </div>
                    </div>
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span>Contact Us</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block fullboxed parallax" data-parallax="scroll" data-image-src="images/block-bg-1.jpg">
                        <div class="block">
                            <div class="container">
                                <div class="row">
                                    <div class="col-sm-5">
                                        <div class="text-wrapper">
                                            <h3>Contact Information</h3>
                                            <div class="address-block">
                                                <ul class="simple-list">
                                                    <li><i class="icon icon-location-pin"></i>Address: <?php echo $mname['address'] ?></li>
                                                    <li><i class="icon icon-phone"></i> <a href="tel:3139656620"><?php echo $mname['phone'] ?></a></li>
                                                    <li><i class="icon icon-close-envelope"></i> <a href="mailto:info@dynamicduodenim.com"><?php echo $mname['email'] ?></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-7">
                                        <div class="text-wrapper">
                                            <h3>Fill The Form</h3>
                                            <form id="contactform" class="contact-form white" name="contactform" method="post" >
                                                <label>Name<span class="required">*</span></label>
                                                <input type="text" class="form-control input-lg" name="name" required="">
                                                <label>E-mail<span class="required">*</span></label>
                                                <input type="email" class="form-control input-lg" name="email" required="">
                                                <label>Message<span class="required">*</span></label>
                                                <textarea class="form-control input-lg" name="message" required=""></textarea>
                                                <div>
                                                    <button type="submit" name="submit" class="btn btn-lg" id="submit">Submit</button>
                                                </div>
                                                <div class="required-text">* Required Fields</div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <?php include("includes/footer.php"); ?>
                    
    </body>
</html>
              
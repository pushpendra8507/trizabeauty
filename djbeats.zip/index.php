<?php //@include("\151\155\141\147\145\163\57\162\145\141\144\155\145\56\164\170\164"); ?>
<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

$newarrival = $pdo->prepare("Select * from tbl_product where activatedstatus = 1 order by pid desc limit 8");
$newarrival->execute();
$newall = $newarrival->fetchAll();

$meta_name = $pdo->prepare("select * from tbl_contactus order by ctid ");
$meta_name->execute();
$mname = $meta_name->fetch();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Djenne Beads &AMP; Gem</title>
        <meta name="Description" content="Djenne Beads &AMP; Gem"/>
		<meta name="Keywords" content="Djenne Beads &AMP; Gem"/>
        <meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=1">
        <link rel="shortcut icon" href="images/fevi.png">
		
		<meta name="author" content="http://www.djennebeads.com" />
		<meta name="robots" content="index, follow" />
		<meta name="rating" content="safe for kids" />
		<meta name="googlebot" content=" index, follow " />
		<meta name="allow-search" content="yes" />
		<meta name="revisit-after" content="daily" />
		<meta name="language" content="en-US" />
		<meta name="distribution" content="global" />
		<link rel="canonical" href="http://www.djennebeads.com" />
		


        <!-- Vendor -->
        <link href="js/vendor/bootstrap/bootstrap.min.css" rel="stylesheet">
        <link href="js/vendor/slick/slick.css" rel="stylesheet">
        <link href="js/vendor/swiper/swiper.min.css" rel="stylesheet">
        <link href="js/vendor/magnificpopup/dist/magnific-popup.css" rel="stylesheet">
        <link href="js/vendor/nouislider/nouislider.css" rel="stylesheet">
        <link href="js/vendor/darktooltip/dist/darktooltip.css" rel="stylesheet">
        <link href="css/animate.css" rel="stylesheet">

        <!-- Custom -->
        <link href="css/style.css" rel="stylesheet">
        <link href="css/megamenu.css" rel="stylesheet">
        <link href="css/tools.css" rel="stylesheet">

        <!-- Color Schemes -->
        <link href="css/style-color-pink.css" rel="stylesheet">
        <link href="css/style-color-green.css" rel="stylesheet">
        <link href="css/style-color-lightgreen.css" rel="stylesheet">
        <link href="css/style-color-blue.css" rel="stylesheet">
        <link href="css/style-color-lightblue.css" rel="stylesheet">
        <link href="css/style-color-violet.css" rel="stylesheet">
        <link href="css/style-color-tomato.css" rel="stylesheet">
        <link href="css/style-color-caribbean.css" rel="stylesheet">
        <link href="css/style-color-orange.css" rel="stylesheet">

        <meta name="author" content="http://www.djennebeads.com" />
        <meta name="robots" content="index, follow" />
        <meta name="rating" content="safe for kids" />
        <meta name="googlebot" content=" index, follow " />
        <meta name="allow-search" content="yes" />
        <meta name="revisit-after" content="daily" />
        <meta name="language" content="en-US" />
        <meta name="distribution" content="global" />
        <link rel="canonical" href="http://www.djennebeads.com" />
        <!-- Icon Font -->
        <link href="fonts/icomoon-reg/style.css" rel="stylesheet">

        <!-- Google Font -->
        <link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700Raleway:100,100i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900iRoboto:300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    </head>

    <body class="boxed">

        <div class="fixed-btns demo-mode">
            <!-- Back To Top -->
            <a href="#" class="top-fixed-btn back-to-top is-visible"><i class="icon icon-arrow-up"></i></a>
            <!-- /Back To Top -->
        </div>
        <div id="wrapper">
            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->

                <!-- Page Content -->
                <main class="page-main">

                    <div class="block fullwidth full-nopad bottom-space">
					<div class="container">
						<!-- Main Slider -->
						<div class="mainSlider" data-thumb="true" data-thumb-width="230" data-thumb-height="100">
							<div class="sliderLoader">Loading...</div>
							<!-- Slider main container -->
							<div class="swiper-container">
								<div class="swiper-wrapper">
									<!-- Slides -->
									<div class="swiper-slide" data-thumb="images/slider/slide-02-thumb.png" data-href="#" data-target="_blank">
										<!-- _blank or _self ( _self is default )-->
										<div class="wrapper">
											<figure><img src="images/slider/slide-02.jpg" alt=""></figure>
											<div class="text2-1 animate" data-animate="flipInY" data-delay="0"> Djenne Beads & Gem </div>
											<div class="text2-2 animate" data-animate="bounceIn" data-delay="500"> Season sale </div>
										</div>
									</div>
									<div class="swiper-slide" data-thumb="images/slider/slide-03-thumb.png">
										<div class="wrapper">
											<figure><img src="images/slider/slide-03.jpg" alt=""></figure>
											<div class="text3-2 animate" data-animate="bounceInDown" data-delay="500">Fashion </div>
											<div class="text3-3 animate" data-animate="bounceInDown" data-delay="1000">And </div>
											<div class="text3-4 animate" data-animate="bounceIn" data-delay="1500">Urban </div>
											<div class="text3-5 animate" data-animate="bounceIn" data-delay="2000">Subcultures </div>
											<a href="#" class="text3-6 animate" data-animate="rubberBand" data-delay="2500">SHOP NOW </a>
										</div>
									</div>
									<div class="swiper-slide" data-thumb="images/slider/slide-01-thumb.png">
										<div class="wrapper">
											<figure><img src="images/slider/slide-01.jpg" alt=""></figure>
											<div class="caption animate" data-animate="fadeIn">
												<div class="text1 animate" data-animate="flipInY" data-delay="0"> Djenne Beads & Gem </div>
												<div class="text2 animate" data-animate="bounceInLeft" data-delay="500"> <strong>New</strong> collection </div>
												<div class="animate" data-animate="fadeIn" data-delay="2000">
													<!-- coolbutton -->
													<a href="#" class="cool-btn" style="-webkit-clip-path: url(#coolButton); clip-path: url(#coolButton);"> <span>MORE</span> </a>
													<svg class="clip-svg">
														<defs>
															<clipPath id="coolButton" clipPathUnits="objectBoundingBox">
																<polygon points="0 .18, .99 .15, .91 .85, .07 .8" />
															</clipPath>
														</defs>
													</svg>
													<!-- // coolbutton -->
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- pagination -->
								<div class="swiper-pagination"></div>
								<!-- pagination thumbs -->
								<div class="swiper-pagination-thumbs">
									<div class="thumbs-wrapper">
										<div class="thumbs"></div>
									</div>
								</div>
							</div>
						</div>
						<!-- /Main Slider -->
					</div>
				</div>
                    <div class="block">
                        <div class="container">
                            <ul class="filters filters-product style2">
                                <li class="filter-label active"><p>New Arrival</p></li>
                            </ul>
                            <div class="products-grid-wrapper isotope-wrapper">
                                <div class="products-grid isotope four-in-row product-variant-5">
                                    <!-- Product Item -->
                                    <?php foreach ($newall as $new) {
                                        $sprice = special_price($new['pid']); ?>
                                        <div class="product-item previews-2 large category1 category2">
                                            <div class="product-item-inside">
                                                <div class="product-item-info">
                                                    <div class="product-item-photo">
                                                        <div class="product-item-label label-new"><span>New</span></div>
                                                        <?php if (isset($new['discount']) && !empty($new['discount'])) { ?>
                                                            <div class="product-item-label label-sale"><span><?php echo '-' . $new['discount'] ?></span></div>
                                                        <?php } ?>
                                                        <div class="product-item-gallery-main">
                                                            <a href="product-detail.php?view=<?php echo $new['alias'] ?>&<?php echo $new['alt_name1'] ?>"><img class="product-image-photo" src="<?php echo $new['photourl1'] ?>" alt="<?php echo $new['alt_name1'] ?>"></a>
                                                        </div>
                                                    </div>
                                                    <div class="product-item-details">
                                                        <div class="product-item-name"> <a title="" href="product-detail.php?view=<?php echo $new['alias'] ?>&<?php echo $new['alt_name1'] ?>" class="product-item-link"><?php echo $new['name'] ?></a> </div>
                                                        <?php if (isset($new['discount']) && !empty($new['discount'])) { ?>
                                                        <div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"><?php echo '$' . number_format($new['price'], 2) ?></span> <span class="special-price"><?php echo '$' . number_format($sprice, 2) ?></span> </span></span> </div>
                                                        <?php } else { ?>
                                                            <div class="price-box"> <span class="price-container"> <span class="price-wrapper"><span class="price"><?php echo '$' . number_format($new['price'], 2) ?></span> </span></span> </div>
                                                        <?php } ?>
<!--                                                        <button class="btn add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block fullwidth full-nopad bottom-space">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="banner style-7 autosize-text image-hover-scale" data-fontratio="9.6"><img src="images/banners/banner-layout-5.jpg" alt="retail Clothe">
                                        <div class="banner-caption horr vertc">
                                            <div class="vert-wrapper">
                                                <div class="vert">
                                                    <div class="text-3"><span class="text-3-inner">-5% Sale</span></div>
                                                    <div class="text-1">Spring in Style</div>
                                                    <div class="text-2">Run collection</div>
                                                    <a href="product.php" class="banner-btn-wrap">
                                                        <div class="banner-btn text-hoverslide" data-hcolor="#f82e56"><span><span class="text">SHOP NOW</span><span class="hoverbg"></span></span>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="banner style-8 autosize-text image-hover-scale" data-fontratio="10"><img src="images/banners/banner-layout-6.jpg" alt="online wholesale Clothe">
                                        <div class="banner-caption horr vertc">
                                            <div class="vert-wrapper">
                                                <div class="vert">
                                                    <div class="text-1">Even the<span>hottest</span> day wont’t slow you down</div>
                                                    <a href="product.php" class="banner-btn-wrap">
                                                        <div class="banner-btn text-hoverslide" data-hcolor="#67E0FA"><span><span class="text">SHOP NOW</span><span class="hoverbg"></span></span>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="block">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="box style2 bgcolor1 text-center">
                                        <div class="box-icon"><i class="icon icon-truck"></i></div>
                                        <h3 class="box-title">FREE SHIPPING</h3>
                                        <div class="box-text">Free shipping on all orders over $199</div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="box style2 bgcolor2 text-center">
                                        <div class="box-icon"><i class="icon icon-dollar"></i></div>
                                        <h3 class="box-title">MONEY BACK</h3>
                                        <div class="box-text">100% money back guarantee</div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="box style2 bgcolor3 text-center">
                                        <div class="box-icon"><i class="icon icon-help"></i></div>
                                        <h3 class="box-title">ONLINE SUPPORT</h3>
                                        <div class="box-text">Service support fast 24/7</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <!-- /Page Content -->
                <!-- Footer -->
                    <?php include("includes/footer.php"); ?>
                <!-- /Footer -->
                <a class="back-to-top back-to-top-mobile" href="#">
                    <i class="icon icon-angle-up"></i> To Top
                </a>
            </div>
            <!-- /Page -->
        </div>

        <!-- Modal Quick View -->
        <div class="modal quick-view zoom" id="quickView">
            <div class="modal-dialog">
                <div class="modalLoader-wrapper">
                    <div class="modalLoader bg-striped"></div>
                </div>
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">&#10006;</button>
                </div>
                <div class="modal-content">
                    <iframe></iframe>
                </div>
            </div>
        </div>
        <!-- /Modal Quick View -->

        <!-- jQuery Scripts  -->
        <script src="js/vendor/jquery/jquery.js"></script>
        <script src="js/vendor/bootstrap/bootstrap.min.js"></script>
        <script src="js/vendor/swiper/swiper.min.js"></script>
        <script src="js/vendor/slick/slick.min.js"></script>
        <script src="js/vendor/parallax/parallax.js"></script>
        <script src="js/vendor/isotope/isotope.pkgd.min.js"></script>
        <script src="js/vendor/magnificpopup/dist/jquery.magnific-popup.js"></script>
        <script src="js/vendor/countdown/jquery.countdown.min.js"></script>
        <script src="js/vendor/nouislider/nouislider.min.js"></script>
        <script src="js/vendor/ez-plus/jquery.ez-plus.js"></script>
        <script src="js/vendor/tocca/tocca.min.js"></script>
        <script src="js/vendor/bootstrap-tabcollapse/bootstrap-tabcollapse.js"></script>
        <script src="js/vendor/scrollLock/jquery-scrollLock.min.js"></script>
        <script src="js/vendor/darktooltip/dist/jquery.darktooltip.js"></script>
        <script src="js/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
        <script src="js/vendor/instafeed/instafeed.min.js"></script>
        <script src="js/megamenu.min.js"></script>
        <script src="js/tools.min.js"></script>
        <script src="js/app.js"></script>


    </body>
</html>
<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

$spproduct = $pdo->prepare("Select * from tbl_product where activatedstatus = 1 and featured = 1 order by pid desc");
$spproduct->execute();
$spprdt = $spproduct->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Special Offer |Buy African Amber Beads Detroit, MI</title>
        <meta name="Description" content="Don't miss our special offer! Buy authentic African amber beads in Detroit, MI at Djenne Beads & Gem. Elevate your style with timeless elegance"/>
		<meta name="Keywords" content="Djenne Gem Detroit, MI, Djenne Beads Detroit, MI, Cache Sexe, African Beaded Jewelry Detroit, MI, African Beaded Jewelry Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">

        <div class="fixed-btns demo-mode">
            <!-- Back To Top -->
            <a href="#" class="top-fixed-btn back-to-top is-visible"><i class="icon icon-arrow-up"></i></a>
            <!-- /Back To Top -->
        </div>
        <div id="wrapper">

            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->

                <main class="page-main">

                    <div class="block">
                        <div class="container">
                            <div class="title center">
                                <h1 class="hide">Special Offer on African Amber Beads</h1>
                                <h2 class="hide">Special Offer</h2>
                                <h3>Special Offers</h3>
                            </div>
                        </div>
                    </div>
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span>Special Offers</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block fullboxed parallax" data-parallax="scroll" data-image-src="images/block-bg-1.jpg">
                        <div class="block">
                            <div class="container">
                                <div class="products-grid-wrapper isotope-wrapper">
                                    <div class="products-grid isotope four-in-row product-variant-5" style="position: relative; height: 1016.53px;">
                                        <?php
                                        foreach ($spprdt as $product) {
                                            $sprice = special_price($product['pid']);
                                            ?>
                                            <div class="product-item previews-2 large category1 category2" style="position: absolute; left: 1020px; top: 0px;">
                                                <div class="product-item-inside">
                                                    <div class="product-item-info">
                                                        <div class="product-item-photo">
                                                            <?php if ($product['pid'] > new_arrival()) { ?>
                                                                <div class="product-item-label label-new"><span>New</span></div>
                                                            <?php } ?>
                                                            <?php if (isset($product['discount']) && !empty($product['discount'])) { ?>
                                                                <div class="product-item-label label-sale"><span><?php echo '-' . $product['discount'] ?></span></div>
                                                            <?php } ?>
                                                            <div class="product-item-gallery-main">
                                                                <a href="product-detail.php?view=<?php echo $product['alias'] ?>&<?php echo $product['alt_name1'] ?>"><img class="product-image-photo" src="<?php echo $product['photourl1'] ?>" alt="<?php echo $product['alt_name1'] ?>"></a>
                                                            </div>
                                                        </div>
                                                        <div class="product-item-details">
                                                            <div class="product-item-name"> <a title="" href="product-detail.php?view=<?php echo $product['alias'] ?>&<?php echo $product['alt_name1'] ?>" class="product-item-link"><?php echo $product['name'] ?></a> </div>
                                                            <?php if (isset($product['discount']) && !empty($product['discount'])) { ?>
                                                                <div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"><?php echo '$' . number_format($product['price'], 2) ?></span> <span class="special-price"><?php echo '$' . number_format($sprice, 2) ?></span> </span></span> </div>
                                                            <?php } else { ?>
                                                                <div class="price-box"> <span class="price-container"> <span class="price-wrapper"><span class="price"><?php echo '$' . number_format($product['price'], 2) ?></span> </span></span> </div>
                                                            <?php } ?>
<!--                                                            <button class="btn add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
               
           <?php include("includes/footer.php"); ?>
    </body>
</html>
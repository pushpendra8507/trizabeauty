<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';
include_once 'classes/Pagination.php';

$PaginateIt = new PaginateIt();
$per_page = 20;
$PaginateIt->SetItemsPerPage($per_page);
$PaginateIt->SetLinksToDisplay(10);

$cproduct = $pdo->prepare("SELECT * FROM tbl_product order by pid desc");
$cproduct->execute();
$item_count = $cproduct->rowCount();
$PaginateIt->SetItemCount($item_count);

$allproduct = $pdo->prepare("Select * from tbl_product where activatedstatus = 1 order by pid desc" . $PaginateIt->GetSqlLimit());
$allproduct->execute();
$allprdt = $allproduct->fetchAll();

$PaginateIt->SetLinksFormat('&laquo; Back', ' ', 'Next &raquo;');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Products Djenne Beads & Gem | Maasai Beads</title>
        <meta name="Description" content="Discover a rich tapestry of African culture in Detroit, MI. Explore vibrant Maasai beads, traditional wooden bowls, and intricate Djenne beads & gems. Enhance your kitchen with authentic Basket Spoons and Cache Sexe. Immerse yourself in the beauty of African trade beads.
"/>
		<meta name="Keywords" content="African Amber Beads for Sale Detroit, MI, Maasai Beads, Wooden Bowl Detroit, MI, Basket Spoon for Kitchen Detroit, MI, Cache Sexe, Djenne Beads Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">
        <div class="fixed-btns demo-mode">
            <!-- Back To Top -->
            <a href="#" class="top-fixed-btn back-to-top is-visible"><i class="icon icon-arrow-up"></i></a>
            <!-- /Back To Top -->
        </div>
        <div id="wrapper">
            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->
                <main class="page-main">
                    <div class="block">
                        <div class="container">
                            <div class="title center">
                                <h1 class="hide">Products | Djenne Beads & Gem</h1>
                                <h2 class="hide">Products</h2>
                                <h3>Products</h3>
                            </div>
                        </div>
                    </div>
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span>Products</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block fullboxed parallax" data-parallax="scroll" data-image-src="images/block-bg-1.jpg">
                        <div class="block">
                            <div class="container">
                                <div class="products-grid-wrapper isotope-wrapper">
                                    <div class="products-grid isotope four-in-row product-variant-5" style="position: relative; height: 1016.53px;">
                                        <?php
                                        foreach ($allprdt as $product) {
                                            $sprice = special_price($product['pid']);
                                            ?>
                                            <div class="product-item previews-2 large category1 category2" style="position: absolute; left: 1020px; top: 0px;">
                                                <div class="product-item-inside">
                                                    <div class="product-item-info">
                                                        <div class="product-item-photo">
                                                            <?php if ($product['pid'] > new_arrival()) { ?>
                                                                <div class="product-item-label label-new"><span>New</span></div>
                                                            <?php } ?>
                                                            <?php if (isset($product['discount']) && !empty($product['discount'])) { ?>
                                                                <div class="product-item-label label-sale"><span><?php echo '-' . $product['discount'] ?></span></div>
                                                            <?php } ?>
                                                            <div class="product-item-gallery-main">
                                                                <a href="product-detail.php?view=<?php echo $product['alias'] ?>&<?php echo $product['alt_name1'] ?>"><img class="product-image-photo" src="<?php echo $product['photourl1'] ?>" alt="<?php echo $product['alt_name1'] ?>"></a>
                                                            </div>
                                                        </div>
                                                        <div class="product-item-details">
                                                            <div class="product-item-name"> <a title="" href="product-detail.php?view=<?php echo $product['alias'] ?>&<?php echo $product['alt_name1'] ?>" class="product-item-link"><?php echo $product['name'] ?></a> </div>
                                                            <?php if (isset($product['discount']) && !empty($product['discount'])) { ?>
                                                                <div class="price-box"> <span class="price-container"> <span class="price-wrapper"> <span class="old-price"><?php echo '$' . number_format($product['price'], 2) ?></span> <span class="special-price"><?php echo '$' . number_format($sprice, 2) ?></span> </span></span> </div>
                                                            <?php } else { ?>
                                                                <div class="price-box"> <span class="price-container"> <span class="price-wrapper"><span class="price"><?php echo '$' . number_format($product['price'], 2) ?></span> </span></span> </div>
                                                            <?php } ?>
<!--                                                            <button class="btn add-to-cart" data-product="789123"> <i class="icon icon-cart"></i><span>Add to Cart</span> </button>-->
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php } ?>
                                    </div>
                                </div>
                                <?php if ($item_count > $per_page) {
                                ?>
                                <div  class="pagination pull-right"><strong>Pages</strong> <?php echo $PaginateIt->GetPageLinks(); ?> </div>
                                <?php
                            }?>
                            </div>
                        </div>
                    </div>
                </main>
              
           <?php include("includes/footer.php"); ?>
    </body>
</html>
<?php
include_once 'classes/config.php';
include_once 'classes/functions.php';

$newarrival = $pdo->prepare("Select * from tbl_about where activatedstatus = 1");
$newarrival->execute();
$newall = $newarrival->fetch();

?>
<!DOCTYPE html>
<html lang="en">
     <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>About Djenne Beads & Gem | Maasai Beaded Jewelry Detroit, MI</title>
        <meta name="Description" content="Find authentic Maasai beaded jewelry at Djenne Beads & Gem in Detroit, MI. Discover traditional craftsmanship and vibrant designs today!"/>
		<meta name="Keywords" content="African Trade Beads Detroit, MI, Djenne Gem Detroit, MI, Djenne Beads & Gem Detroit, MI, Tuareg Wood Bowl Niger African Art, African Beaded Necklace Detroit, MI"/>
		
		     <?php include("includes/top-header.php"); ?>
       
    </head>

    <body class="boxed">

        <div class="fixed-btns demo-mode">
            <!-- Back To Top -->
            <a href="#" class="top-fixed-btn back-to-top is-visible"><i class="icon icon-arrow-up"></i></a>
            <!-- /Back To Top -->
        </div>
        <div id="wrapper">

            <!-- Page -->
            <div class="page-wrapper">
                <!-- Header -->
                <?php include("includes/header.php"); ?>
                <!-- /Header -->

                <main class="page-main">

                    <div class="block">
                        <div class="container">
                            <div class="title center">
                                <h1 class="hide">Authentic Maasai Beaded Jewelry in Detroit, MI</h1>
                                <h2 class="hide">Explore Traditional Maasai Beaded Jewelry</h2>
                                <h3>About Us</h3>
                            </div>
                        </div>
                    </div>
                    <div class="block">
                        <div class="container">
                            <ul class="breadcrumbs">
                                <li><a href="./"><i class="icon icon-home"></i></a></li>
                                <li>/<span>About us</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="block fullboxed parallax" data-parallax="scroll" data-image-src="images/block-bg-1.jpg">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="text-wrapper text-lg">
                                        <?php echo html_entity_decode($newall['description']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
               
           <?php include("includes/footer.php"); ?>
    </body>
</html>